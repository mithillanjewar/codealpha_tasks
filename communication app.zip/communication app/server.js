const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const multer = require('multer');
const jwt = require('jsonwebtoken');
const Database = require('./db');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'secure_rtc_encryption_jwt_secret_token_12345';

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Ensure upload directory exists
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR);
}

// Multer storage configuration for encrypted file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOAD_DIR);
  },
  filename: (req, file, cb) => {
    // Save files with a random unique name to prevent collisions/information leakage
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, 'enc-' + uniqueSuffix);
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB limit
});

// Middleware to verify JWT token
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
}

// --- REST API ENDPOINTS ---

// Auth - Signup
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password || username.trim() === '' || password.trim() === '') {
      return res.status(400).json({ error: 'Username and password are required' });
    }
    if (username.length < 3) {
      return res.status(400).json({ error: 'Username must be at least 3 characters long' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long' });
    }

    const newUser = await Database.createUser(username, password);
    const token = jwt.sign({ id: newUser.id, username: newUser.username }, JWT_SECRET, { expiresIn: '24h' });
    
    res.status(201).json({ message: 'User created successfully', token, user: newUser });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Auth - Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    const user = await Database.verifyUser(username, password);
    if (!user) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '24h' });
    res.status(200).json({ message: 'Login successful', token, user });
  } catch (error) {
    res.status(500).json({ error: 'Server error during login' });
  }
});

// Auth - Verify current session
app.get('/api/auth/me', authenticateToken, (req, res) => {
  res.status(200).json({ user: req.user });
});

// File Upload (Encrypted data)
app.post('/api/files/upload', authenticateToken, upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  // Respond with the file id (filename) and the original name (encrypted on client)
  res.status(200).json({
    fileId: req.file.filename,
    size: req.file.size
  });
});

// File Download (Encrypted data)
app.get('/api/files/download/:fileId', authenticateToken, (req, res) => {
  const fileId = req.params.fileId;
  const filePath = path.join(UPLOAD_DIR, fileId);

  // Security check: ensure path traversal is prevented
  if (!fileId.startsWith('enc-') || !fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'File not found' });
  }

  res.download(filePath, (err) => {
    if (err) {
      console.error('File download error:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Error downloading file' });
      }
    }
  });
});

// --- SOCKET.IO SIGNALLING & COLLABORATION CHANNEL ---

// Maps socket.id to user info (room, username)
const socketToUser = new Map();

io.on('connection', (socket) => {
  console.log(`Socket connected: ${socket.id}`);

  // Handle client joining a room
  socket.on('join-room', ({ roomId, username }) => {
    socket.join(roomId);
    socketToUser.set(socket.id, { roomId, username });
    
    console.log(`User ${username} (${socket.id}) joined room ${roomId}`);

    // Get list of other users in the room
    const clientsInRoom = io.sockets.adapter.rooms.get(roomId);
    const otherUsers = [];

    if (clientsInRoom) {
      clientsInRoom.forEach(clientSocketId => {
        if (clientSocketId !== socket.id) {
          const userDetails = socketToUser.get(clientSocketId);
          otherUsers.push({
            socketId: clientSocketId,
            username: userDetails ? userDetails.username : 'Unknown User'
          });
        }
      });
    }

    // Send the list of existing users back to the joining user
    socket.emit('room-users', otherUsers);

    // Notify other users in the room that a new user has joined
    socket.to(roomId).emit('user-connected', {
      socketId: socket.id,
      username: username
    });
  });

  // Relay WebRTC signalling (offer, answer, candidates) to specific peer
  socket.on('signal', ({ targetSocketId, signalData }) => {
    const senderDetails = socketToUser.get(socket.id);
    io.to(targetSocketId).emit('signal', {
      senderSocketId: socket.id,
      senderUsername: senderDetails ? senderDetails.username : 'Unknown User',
      signalData
    });
  });

  // Relay chat message to the room
  socket.on('chat-message', (encryptedPayload) => {
    const userDetails = socketToUser.get(socket.id);
    if (userDetails) {
      const { roomId, username } = userDetails;
      // Broadcast to other users in the room
      socket.to(roomId).emit('chat-message', {
        senderId: socket.id,
        senderUsername: username,
        payload: encryptedPayload,
        timestamp: new Date().toISOString()
      });
    }
  });

  // Relay shared file announcement to the room
  socket.on('file-shared', (fileMetadata) => {
    const userDetails = socketToUser.get(socket.id);
    if (userDetails) {
      const { roomId, username } = userDetails;
      // Broadcast file info to others
      socket.to(roomId).emit('file-shared', {
        senderId: socket.id,
        senderUsername: username,
        fileMetadata,
        timestamp: new Date().toISOString()
      });
    }
  });

  // Relay whiteboard draw commands
  socket.on('draw', (drawData) => {
    const userDetails = socketToUser.get(socket.id);
    if (userDetails) {
      socket.to(userDetails.roomId).emit('draw', {
        senderId: socket.id,
        drawData
      });
    }
  });

  // Relay whiteboard clear command
  socket.on('clear-canvas', () => {
    const userDetails = socketToUser.get(socket.id);
    if (userDetails) {
      socket.to(userDetails.roomId).emit('clear-canvas');
    }
  });

  // Handle client disconnection
  socket.on('disconnect', () => {
    const userDetails = socketToUser.get(socket.id);
    if (userDetails) {
      const { roomId, username } = userDetails;
      console.log(`User ${username} (${socket.id}) disconnected`);
      
      // Notify other peers in the room
      socket.to(roomId).emit('user-disconnected', {
        socketId: socket.id,
        username: username
      });
      
      socketToUser.delete(socket.id);
    }
  });
});

// Start Server
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
