const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const DB_PATH = path.join(__dirname, 'db.json');

// Initialize database if it doesn't exist
function initDb() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({ users: [] }, null, 2), 'utf8');
  }
}

// Read database contents
function readDb() {
  initDb();
  try {
    const data = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading database file:', error);
    return { users: [] };
  }
}

// Write database contents
function writeDb(data) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
  } catch (error) {
    console.error('Error writing to database file:', error);
  }
}

// User helper methods
const Database = {
  // Find a user by username
  findUser: (username) => {
    const db = readDb();
    return db.users.find(u => u.username.toLowerCase() === username.toLowerCase());
  },

  // Create a new user
  createUser: async (username, password) => {
    const db = readDb();
    
    // Check if user already exists
    const exists = db.users.some(u => u.username.toLowerCase() === username.toLowerCase());
    if (exists) {
      throw new Error('Username is already taken');
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newUser = {
      id: Math.random().toString(36).substring(2, 9),
      username,
      password: hashedPassword,
      createdAt: new Date().toISOString()
    };

    db.users.push(newUser);
    writeDb(db);

    return { id: newUser.id, username: newUser.username };
  },

  // Verify password matches username
  verifyUser: async (username, password) => {
    const user = Database.findUser(username);
    if (!user) return false;

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return false;

    return { id: user.id, username: user.username };
  }
};

module.exports = Database;
