# AetherMeet 🌌

A state-of-the-art, secure video conferencing and real-time collaboration tool built from scratch using HTML, Vanilla CSS, and JavaScript on the frontend, and Node.js with Express and Socket.io on the backend.

AetherMeet features rich glassmorphic aesthetics, multi-user WebRTC video calling, screen sharing, whiteboard drawing, secure user authentication, and client-side **End-to-End Encryption (E2EE)** for messages and files using the native Web Crypto API.

---

## 🚀 Key Features

*   **Secure User Accounts**: JWT-based session nodes with passwords hashed using `bcryptjs` on signup.
*   **WebRTC Multi-User Video Grid**: Relies on a decentralized peer-to-peer mesh network to transmit media streams directly between clients, coordinated by a Socket.io signaling server.
*   **True End-to-End Encryption (E2EE)**: Room passwords are used to derive 256-bit AES-GCM keys locally on the client using PBKDF2. **Keys are never shared with or sent to the server.**
*   **E2EE File Sharing**: Files are encrypted client-side using Web Crypto, uploaded as binary blobs, and downloaded by peers who decrypt them locally.
*   **E2EE Real-Time Chat**: Messages are encrypted locally and decrypted only by clients holding the correct room key.
*   **Collaborative Whiteboard**: Synchronizes drawings across devices, mapping coordinates to a logical `1200x800` canvas to ensure alignment across different screen sizes.
*   **Active Speaker Indicators**: Measures audio track amplitude client-side using `AudioContext` and `AnalyserNode` to glow the border of the active speaker.
*   **Screen Sharing**: Seamless track switching in peer connections using standard media device capture.
*   **Premium Visual Experience**: Modern dark-mode glassmorphic theme with animated background gradient orbs and responsive layout grids.

---

## 📂 Project Structure

```
e:\communication app\
├── package.json               # Backend configurations and scripts
├── server.js                  # Express & Socket.io server (Signaling, File upload APIs)
├── db.js                      # Secure JSON file-based database helper
├── db.json                    # User database storage (gitignored/local)
├── uploads/                   # Temporary directory for encrypted file uploads
└── public/                    # Frontend files
    ├── index.html             # Landing, Auth & Lobby page
    ├── room.html              # Main Video-Conferencing & Collaboration room
    ├── css/
    │   └── style.css          # Design system, glassmorphism, animations
    └── js/
        ├── auth.js            # Authentication API handlers and session manager
        ├── crypto.js          # Web Crypto client wrapper (AES-GCM encryption/decryption)
        ├── whiteboard.js      # Interactive canvas listener and drawing renderer
        └── room.js            # Media setup, WebRTC mesh, Socket.io listeners
```

---

## 🛠️ Installation & Setup

1.  **Clone or Open the directory** in your command line.
2.  **Install dependencies**:
    ```bash
    npm install
    ```
3.  **Start the server**:
    ```bash
    npm start
    ```
4.  **Access the application**:
    Open [http://localhost:3000](http://localhost:3000) in your web browser.

---

## 🧪 Verification Tests

We included verification scripts to automate API route and cryptographic checks:

*   **Auth Endpoint Tests**: Runs registration, correct password login, incorrect password login, and JWT route protections.
*   **E2EE File Transfer Tests**: Runs key derivation, binary buffer encryption (AES-GCM), multipart upload to Express, file download, and decryption validation.

To run tests (ensure the server is running first):
```bash
# From the project directory, run node on the verification scripts:
node "C:\Users\admin\.gemini\antigravity\brain\6f8004e0-8fbe-4718-8940-d5bf04ff30df\scratch\verify_api.js"
node "C:\Users\admin\.gemini\antigravity\brain\6f8004e0-8fbe-4718-8940-d5bf04ff30df\scratch\verify_files.js"
```

---

## 🔒 Cryptographic Architecture Notes

1.  **Key Derivation (PBKDF2)**:
    We take the room password entered by the user and derive a key using PBKDF2:
    - Hash function: SHA-256
    - Iterations: 100,000
    - Salt: Room Name + Static Salt token
2.  **Encryption Protocol (AES-GCM)**:
    All encrypted payloads (text & files) use 256-bit AES-GCM:
    - A unique 12-byte Initialization Vector (IV) is generated dynamically for every single encryption.
    - Decryption reads the IV prepended to the ciphertext block.
3.  **No Server Knowledge**:
    Because the room password remains in `sessionStorage` and is never sent to the network, the Node.js server serves purely as a packet relay and encrypted chunk storage block. Data privacy is mathematically guaranteed!
