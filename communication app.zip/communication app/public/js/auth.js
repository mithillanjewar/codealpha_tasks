/**
 * Client authentication and session manager.
 */

const AuthManager = {
  // Save JWT in session storage (cleared when browser tab closes)
  setToken(token) {
    sessionStorage.setItem('rtc_auth_token', token);
  },

  getToken() {
    return sessionStorage.getItem('rtc_auth_token');
  },

  setUser(user) {
    sessionStorage.setItem('rtc_user_details', JSON.stringify(user));
  },

  getUser() {
    const userJson = sessionStorage.getItem('rtc_user_details');
    try {
      return userJson ? JSON.parse(userJson) : null;
    } catch {
      return null;
    }
  },

  clearSession() {
    sessionStorage.removeItem('rtc_auth_token');
    sessionStorage.removeItem('rtc_user_details');
  },

  // Generates API headers including Bearer Token
  getHeaders() {
    const headers = {
      'Content-Type': 'application/json'
    };
    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  },

  /**
   * Register a new user
   */
  async signup(username, password) {
    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Signup failed');
      }

      this.setToken(data.token);
      this.setUser(data.user);
      return data.user;
    } catch (error) {
      console.error('Signup Error:', error);
      throw error;
    }
  },

  /**
   * Log in an existing user
   */
  async login(username, password) {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Login failed');
      }

      this.setToken(data.token);
      this.setUser(data.user);
      return data.user;
    } catch (error) {
      console.error('Login Error:', error);
      throw error;
    }
  },

  /**
   * Checks if user has a valid active session
   */
  async checkSession() {
    const token = this.getToken();
    if (!token) return false;

    try {
      const response = await fetch('/api/auth/me', {
        method: 'GET',
        headers: this.getHeaders()
      });

      if (response.ok) {
        const data = await response.ok ? await response.json() : null;
        if (data && data.user) {
          this.setUser(data.user);
          return true;
        }
      }
      
      // Token is invalid/expired
      this.clearSession();
      return false;
    } catch (err) {
      console.error('Session verify failed:', err);
      // Assume offline or server error, rely on local token for now
      return !!this.getUser();
    }
  },

  /**
   * Require login on page access
   */
  requireAuth() {
    if (!this.getToken()) {
      window.location.href = '/index.html';
    }
  }
};
