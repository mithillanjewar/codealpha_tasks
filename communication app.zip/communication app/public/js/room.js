/**
 * Main WebRTC & Collaboration UI Controller
 */

document.addEventListener('DOMContentLoaded', async () => {
  // Guard access: require login
  AuthManager.requireAuth();

  const urlParams = new URLSearchParams(window.location.search);
  const roomId = urlParams.get('id');

  if (!roomId) {
    window.location.href = 'index.html';
    return;
  }

  // Set Room ID in header
  document.getElementById('header-room-id').textContent = roomId;

  // State Variables
  let roomKey = null;
  let socket = null;
  let localStream = null;
  let localScreenStream = null;
  let isScreenSharing = false;
  let isAudioEnabled = true;
  let isVideoEnabled = true;
  let whiteboard = null;
  
  // Peer storage: socketId -> { connection, username, stream, container }
  const peers = new Map();

  // WebRTC ICE configurations (public Google STUN servers)
  const rtcConfig = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' }
    ]
  };

  // --- CRYPTO INITIALIZATION ---
  const roomPassword = sessionStorage.getItem('rtc_room_pwd');
  if (!roomPassword) {
    // Show password overlay if missing
    const passwordOverlay = document.getElementById('password-prompt-overlay');
    passwordOverlay.style.display = 'flex';
    
    document.getElementById('prompt-submit-btn').addEventListener('click', async () => {
      const pwdInput = document.getElementById('prompt-room-pwd').value;
      if (!pwdInput || pwdInput.trim() === '') {
        alert('Password is required.');
        return;
      }
      sessionStorage.setItem('rtc_room_pwd', pwdInput);
      passwordOverlay.style.display = 'none';
      await initializeRoom(pwdInput);
    });
  } else {
    await initializeRoom(roomPassword);
  }

  // Core Room Initialization
  async function initializeRoom(password) {
    showToast('Initializing secure key exchanges...');
    try {
      // Derive E2EE Key
      roomKey = await CryptoEngine.deriveKey(password, roomId);
      
      if (!CryptoEngine.isSecureContext()) {
        const badge = document.querySelector('.security-badge');
        if (badge) {
          badge.style.background = 'rgba(239, 68, 68, 0.1)';
          badge.style.borderColor = 'rgba(239, 68, 68, 0.3)';
          badge.style.color = 'var(--accent-red)';
          badge.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> E2EE DISABLED';
        }
        document.getElementById('fingerprint-value').textContent = 'INSECURE';
        showToast('Insecure browser context: running in E2EE fallback mode.', 'error');
      } else {
        // Calculate a visual fingerprint of the key to display in the UI (SHA-256 hash of password)
        const encoder = new TextEncoder();
        const hashBuffer = await crypto.subtle.digest('SHA-256', encoder.encode(password + roomId));
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        document.getElementById('fingerprint-value').textContent = hashHex.substring(0, 10).toUpperCase();
        showToast('E2EE Keys derived successfully.', 'success');
      }
      
      // Start media stream and connect to sockets
      await startMediaStream();
      connectSocket();
      initializeWhiteboard();
      initializeUIHandlers();
    } catch (err) {
      console.error('Initialization failed:', err);
      showToast('Key derivation failed. Please reload.', 'error');
    }
  }

  // --- MEDIA CONTROLLER ---
  async function startMediaStream() {
    try {
      localStream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: {
          width: { ideal: 640 },
          height: { ideal: 360 },
          frameRate: { ideal: 24 }
        }
      });

      const localVideo = document.getElementById('local-video');
      localVideo.srcObject = localStream;
      
      const user = AuthManager.getUser();
      document.getElementById('local-username-tag').textContent = `You (${user.username})`;

      // Monitor local voice audio
      monitorAudioLevel(localStream, 'local-video-container');
    } catch (error) {
      console.error('Error accessing media devices:', error);
      showToast('Camera/Mic permission denied. Joining without media.', 'error');
      // Create a fallback empty stream so peer connections don't break entirely
      localStream = new MediaStream();
    }
  }

  // --- SIGNALLING GATEWAY (SOCKET.IO) ---
  function connectSocket() {
    const user = AuthManager.getUser();
    socket = io();

    socket.on('connect', () => {
      console.log('Connected to signaling server');
      socket.emit('join-room', { roomId, username: user.username });
    });

    // Received list of current users in room (Initiator role)
    socket.on('room-users', (users) => {
      console.log('Room users received:', users);
      users.forEach(peer => {
        // Create PeerConnection, act as caller (createOffer = true)
        createPeerConnection(peer.socketId, peer.username, true);
      });
    });

    // A new user joined the room (Receiver role)
    socket.on('user-connected', ({ socketId, username }) => {
      console.log(`User connected: ${username} (${socketId})`);
      showToast(`${username} entered the room.`);
      // The joining user is the one who initiates the offers, so here we wait for their offer.
    });

    // Handle WebRTC signaling signals (relayed via Socket.io)
    socket.on('signal', async ({ senderSocketId, senderUsername, signalData }) => {
      let peer = peers.get(senderSocketId);
      
      // If peer connection doesn't exist, create it (caller = false, waiting for their offer)
      if (!peer) {
        peer = createPeerConnection(senderSocketId, senderUsername, false);
      }

      const { connection } = peer;

      try {
        if (signalData.sdp) {
          const desc = new RTCSessionDescription(signalData.sdp);
          await connection.setRemoteDescription(desc);

          if (desc.type === 'offer') {
            const answer = await connection.createAnswer();
            await connection.setLocalDescription(answer);
            socket.emit('signal', {
              targetSocketId: senderSocketId,
              signalData: { sdp: connection.localDescription }
            });
          }

          // Process any queued ICE candidates that arrived before the remote description was set
          if (peer.candidateQueue && peer.candidateQueue.length > 0) {
            console.log(`Processing ${peer.candidateQueue.length} queued ICE candidates for ${senderUsername}`);
            for (const cand of peer.candidateQueue) {
              await connection.addIceCandidate(cand).catch(e => console.warn('Queued candidate add failed:', e));
            }
            peer.candidateQueue = [];
          }
        } else if (signalData.candidate) {
          const cand = new RTCIceCandidate(signalData.candidate);
          // If remote description is ready, add ICE candidate; otherwise, queue it to avoid state errors
          if (connection.remoteDescription && connection.remoteDescription.type) {
            await connection.addIceCandidate(cand);
          } else {
            console.log(`Queuing ICE candidate from ${senderUsername} (SDP description not set yet)`);
            peer.candidateQueue.push(cand);
          }
        }
      } catch (err) {
        console.error('Signaling processing error:', err);
      }
    });

    // Whiteboard Sync Relay
    socket.on('draw', ({ senderId, drawData }) => {
      if (whiteboard) {
        whiteboard.drawSegment(drawData);
      }
    });

    socket.on('clear-canvas', () => {
      if (whiteboard) {
        whiteboard.clearLocal();
      }
    });

    // Encrypted Chat Relay
    socket.on('chat-message', async ({ senderUsername, payload, timestamp }) => {
      try {
        const decryptedMessage = await CryptoEngine.decryptText(payload, roomKey);
        renderChatMessage(senderUsername, decryptedMessage, false, timestamp);
      } catch (err) {
        console.error('Chat decryption failed:', err);
        renderChatMessage(senderUsername, '🔒 [Decryption Error: Key mismatch]', false, timestamp);
      }
    });

    // Encrypted File Shared Relay
    socket.on('file-shared', async ({ senderUsername, fileMetadata, timestamp }) => {
      try {
        const decryptedName = await CryptoEngine.decryptText(fileMetadata.encryptedName, roomKey);
        renderFileCard(senderUsername, {
          fileId: fileMetadata.fileId,
          name: decryptedName,
          size: fileMetadata.size,
          type: fileMetadata.type
        }, false);
      } catch (err) {
        console.error('File decryption failed:', err);
        showToast('Decryption error on a shared file.', 'error');
      }
    });

    // User Left Room
    socket.on('user-disconnected', ({ socketId, username }) => {
      console.log(`User disconnected: ${username} (${socketId})`);
      showToast(`${username} left the room.`);
      
      const peerObj = peers.get(socketId);
      if (peerObj) {
        if (peerObj.connection) {
          peerObj.connection.close();
        }
        if (peerObj.container) {
          peerObj.container.remove();
        }
        peers.delete(socketId);
      }
      updateActivePeersList();
    });
  }

  // --- WEBRTC CONNECTION CREATION ---
  function createPeerConnection(peerSocketId, peerUsername, isCaller) {
    console.log(`Creating RTCPeerConnection for ${peerUsername}. Caller: ${isCaller}`);
    
    const connection = new RTCPeerConnection(rtcConfig);

    // Add local media tracks to connection
    if (localStream) {
      localStream.getTracks().forEach(track => {
        connection.addTrack(track, localStream);
      });
    }

    // Handle ICE Candidates
    connection.onicecandidate = (event) => {
      if (event.candidate) {
        socket.emit('signal', {
          targetSocketId: peerSocketId,
          signalData: { candidate: event.candidate }
        });
      }
    };

    // Handle Remote Track arrival
    connection.ontrack = (event) => {
      console.log(`Remote track received from ${peerUsername}`, event.streams[0]);
      setupRemoteVideo(peerSocketId, peerUsername, event.streams[0]);
    };

    // Monitor connection states
    connection.onconnectionstatechange = () => {
      console.log(`Connection state with ${peerUsername}: ${connection.connectionState}`);
      if (connection.connectionState === 'disconnected' || connection.connectionState === 'failed') {
        // Clean up connection
        const peerObj = peers.get(peerSocketId);
        if (peerObj && peerObj.container) {
          peerObj.container.remove();
        }
        peers.delete(peerSocketId);
        updateActivePeersList();
      }
    };

    const peerObj = {
      connection,
      username: peerUsername,
      stream: null,
      container: null,
      candidateQueue: [] // Queue for ICE candidates that arrive before Remote Description is set
    };

    peers.set(peerSocketId, peerObj);
    updateActivePeersList();

    // If caller, negotiate offer
    if (isCaller) {
      connection.onnegotiationneeded = async () => {
        try {
          console.log(`Negotiation needed for peer: ${peerUsername}`);
          const offer = await connection.createOffer();
          await connection.setLocalDescription(offer);
          socket.emit('signal', {
            targetSocketId: peerSocketId,
            signalData: { sdp: connection.localDescription }
          });
        } catch (err) {
          console.error('Error creating local offer:', err);
        }
      };
    }

    return peerObj;
  }

  // --- RENDER REMOTE VIDEO STREAM ---
  function setupRemoteVideo(peerSocketId, username, remoteStream) {
    const peerObj = peers.get(peerSocketId);
    if (!peerObj) return;

    peerObj.stream = remoteStream;

    // Check if video container already exists
    let container = document.getElementById(`video-container-${peerSocketId}`);
    if (!container) {
      container = document.createElement('div');
      container.id = `video-container-${peerSocketId}`;
      container.className = 'video-container';

      // Check if this stream is screen sharing (if we want to style it differently)
      // Standard screenshare streams typically have video-only or special tags.
      // For simple mesh, it renders like a normal video grid element.
      
      const videoElement = document.createElement('video');
      videoElement.autoplay = true;
      videoElement.playsInline = true;
      videoElement.srcObject = remoteStream;

      // Note: Do not mirror remote videos (only mirror local camera)
      videoElement.style.transform = 'scaleX(1)';

      const nameTag = document.createElement('div');
      nameTag.className = 'peer-name';
      nameTag.innerHTML = `<i class="fa-solid fa-circle-user" style="color: var(--accent-cyan);"></i> <span>${username}</span>`;

      const controlsIndicator = document.createElement('div');
      controlsIndicator.className = 'peer-controls-indicator';
      controlsIndicator.id = `controls-indicator-${peerSocketId}`;
      
      // Mic Muted indicator icon
      const micMutedIcon = document.createElement('div');
      micMutedIcon.className = 'indicator-icon muted';
      micMutedIcon.id = `mic-muted-${peerSocketId}`;
      micMutedIcon.style.display = 'none';
      micMutedIcon.innerHTML = `<i class="fa-solid fa-microphone-slash"></i>`;
      controlsIndicator.appendChild(micMutedIcon);

      container.appendChild(videoElement);
      container.appendChild(nameTag);
      container.appendChild(controlsIndicator);
      
      document.getElementById('video-streams-grid').appendChild(container);
      peerObj.container = container;
    } else {
      const videoElement = container.querySelector('video');
      if (videoElement.srcObject !== remoteStream) {
        videoElement.srcObject = remoteStream;
      }
    }

    // Monitor remote speaker level
    monitorAudioLevel(remoteStream, container.id);
  }

  // --- AUDIO LEVEL ANALYZER (ACTIVE SPEAKER SHINE) ---
  function monitorAudioLevel(stream, elementId) {
    const audioTracks = stream.getAudioTracks();
    if (audioTracks.length === 0) return;

    try {
      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 512;
      source.connect(analyser);

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      const element = document.getElementById(elementId);
      
      let speakingInterval = setInterval(() => {
        // Stop analyzing if the stream is dead or container is removed
        if (!document.getElementById(elementId) || stream.getAudioTracks().length === 0) {
          clearInterval(speakingInterval);
          audioCtx.close();
          return;
        }

        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        
        const average = sum / bufferLength;
        const volumeThreshold = 25; // Sound amplitude threshold (0-255)

        if (average > volumeThreshold) {
          element.classList.add('speaking');
        } else {
          element.classList.remove('speaking');
        }
      }, 150);
    } catch (e) {
      console.warn('Audio Context analyze not supported or blocked by permissions:', e);
    }
  }

  // --- SHARED WHITEBOARD MANAGEMENT ---
  function initializeWhiteboard() {
    whiteboard = new WhiteboardManager(
      'whiteboard-canvas',
      (drawSegmentData) => {
        // Emit coordinates to socket
        if (socket) socket.emit('draw', drawSegmentData);
      },
      () => {
        // Emit clear canvas command
        if (socket) socket.emit('clear-canvas');
      }
    );

    // Bind local tools controls
    const colorOptions = document.querySelectorAll('.color-option');
    colorOptions.forEach(opt => {
      opt.addEventListener('click', (e) => {
        colorOptions.forEach(o => o.classList.remove('active'));
        opt.classList.add('active');
        whiteboard.setColor(opt.dataset.color);
      });
    });

    const brushSlider = document.getElementById('brush-size');
    const brushVal = document.getElementById('brush-size-val');
    brushSlider.addEventListener('input', (e) => {
      const val = e.target.value;
      brushVal.textContent = `${val}px`;
      whiteboard.setBrushSize(val);
    });

    const eraserBtn = document.getElementById('tool-eraser');
    eraserBtn.addEventListener('click', () => {
      const isErasing = !whiteboard.isEraser;
      whiteboard.setEraser(isErasing);
      if (isErasing) {
        eraserBtn.classList.add('active');
      } else {
        eraserBtn.classList.remove('active');
      }
    });

    document.getElementById('tool-clear').addEventListener('click', () => {
      if (confirm('Clear the shared whiteboard canvas for everyone?')) {
        whiteboard.clear();
      }
    });

    // Close whiteboard
    document.getElementById('close-whiteboard').addEventListener('click', () => {
      document.getElementById('whiteboard-pane').style.display = 'none';
      document.getElementById('toggle-whiteboard').classList.remove('active');
    });
  }

  // --- E2EE CHAT LOGIC ---
  const chatInput = document.getElementById('chat-input');
  const chatSendBtn = document.getElementById('chat-send-btn');

  async function sendChatMessage() {
    const text = chatInput.value.trim();
    if (!text) return;

    try {
      // Encrypt locally using derived key
      const encryptedPayload = await CryptoEngine.encryptText(text, roomKey);
      
      // Emit to server
      if (socket) {
        socket.emit('chat-message', encryptedPayload);
      }

      // Render local chat bubble immediately
      const user = AuthManager.getUser();
      renderChatMessage(user.username, text, true, new Date().toISOString());
      chatInput.value = '';
    } catch (err) {
      console.error('Chat encryption failed:', err);
      showToast('Failed to encrypt message.', 'error');
    }
  }

  chatSendBtn.addEventListener('click', sendChatMessage);
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      sendChatMessage();
    }
  });

  function renderChatMessage(sender, text, isLocal, timestamp) {
    const chatContainer = document.getElementById('chat-messages-container');
    const bubble = document.createElement('div');
    bubble.className = `message-bubble ${isLocal ? 'outgoing' : 'incoming'}`;

    const dateStr = new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    bubble.innerHTML = `
      ${!isLocal ? `<div class="message-sender">${sender}</div>` : ''}
      <div class="message-text">${escapeHtml(text)}</div>
      <div class="message-meta">
        <span>${isLocal ? '<i class="fa-solid fa-lock" style="font-size: 0.65rem;"></i> E2EE' : ''}</span>
        <span>${dateStr}</span>
      </div>
    `;

    chatContainer.appendChild(bubble);
    chatContainer.scrollTop = chatContainer.scrollHeight;
  }

  // --- E2EE FILE SHARING LOGIC ---
  const fileInput = document.getElementById('file-input');
  const fileDropzone = document.getElementById('file-dropzone');
  const uploadProgressBar = document.getElementById('upload-progress-bar');
  const uploadProgressContainer = document.getElementById('upload-progress-container');

  // Trigger input open
  fileDropzone.addEventListener('click', () => fileInput.click());

  // Prevent default drag events
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    fileDropzone.addEventListener(eventName, e => e.preventDefault(), false);
  });

  // Drop handle
  fileDropzone.addEventListener('drop', (e) => {
    const dt = e.dataTransfer;
    const files = dt.files;
    if (files.length > 0) {
      handleFileShare(files[0]);
    }
  });

  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      handleFileShare(e.target.files[0]);
    }
  });

  async function handleFileShare(file) {
    if (!file) return;

    showToast(`Encrypting "${file.name}"...`);
    uploadProgressContainer.style.display = 'block';
    uploadProgressBar.style.width = '10%';

    try {
      const fileReader = new FileReader();
      
      fileReader.onload = async (event) => {
        uploadProgressBar.style.width = '30%';
        const fileDataBuffer = event.target.result;
        
        // 1. Encrypt file binary buffer locally
        const encryptedFileBuffer = await CryptoEngine.encryptFile(fileDataBuffer, roomKey);
        
        // 2. Encrypt file name for privacy
        const encryptedNamePayload = await CryptoEngine.encryptText(file.name, roomKey);

        uploadProgressBar.style.width = '50%';
        
        // 3. Prepare Multi-part upload
        const blob = new Blob([encryptedFileBuffer], { type: 'application/octet-stream' });
        const formData = new FormData();
        formData.append('file', blob, 'enc-blob');

        // 4. Upload encrypted blob to Node backend
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/files/upload', true);
        xhr.setRequestHeader('Authorization', `Bearer ${AuthManager.getToken()}`);

        xhr.upload.onprogress = (event) => {
          if (event.lengthComputable) {
            const percentComplete = (event.loaded / event.total) * 40; // Allocate 50-90% to upload progress
            uploadProgressBar.style.width = `${50 + percentComplete}%`;
          }
        };

        xhr.onload = () => {
          uploadProgressContainer.style.display = 'none';
          uploadProgressBar.style.width = '0%';
          
          if (xhr.status === 200) {
            const result = JSON.parse(xhr.responseText);
            showToast('File uploaded and secured!', 'success');

            // 5. Broadcast file link payload with encrypted filename to room
            const fileShareMetadata = {
              fileId: result.fileId,
              encryptedName: encryptedNamePayload,
              size: file.size,
              type: file.type
            };

            if (socket) {
              socket.emit('file-shared', fileShareMetadata);
            }

            // Render locally
            const user = AuthManager.getUser();
            renderFileCard(user.username, {
              fileId: result.fileId,
              name: file.name,
              size: file.size,
              type: file.type
            }, true);
          } else {
            showToast('File upload failed on server.', 'error');
          }
        };

        xhr.onerror = () => {
          uploadProgressContainer.style.display = 'none';
          showToast('Network error during file upload.', 'error');
        };

        xhr.send(formData);
      };

      fileReader.readAsArrayBuffer(file);
    } catch (err) {
      console.error('File share encryption error:', err);
      uploadProgressContainer.style.display = 'none';
      showToast('Failed to encrypt file.', 'error');
    }
  }

  function renderFileCard(senderUsername, fileData, isLocal) {
    const listContainer = document.getElementById('files-list-container');
    const card = document.createElement('div');
    card.className = 'file-card';
    card.id = `file-card-${fileData.fileId}`;

    const sizeStr = formatBytes(fileData.size);

    card.innerHTML = `
      <div class="file-info">
        <div class="file-name" title="${fileData.name}">${fileData.name}</div>
        <div class="file-size">${sizeStr} • Shared by ${isLocal ? 'You' : senderUsername}</div>
      </div>
      <button class="file-download-btn" id="dl-btn-${fileData.fileId}" title="Download and Decrypt File">
        <i class="fa-solid fa-cloud-arrow-down"></i>
      </button>
    `;

    listContainer.appendChild(card);
    listContainer.scrollTop = listContainer.scrollHeight;

    // Attach Download Event
    document.getElementById(`dl-btn-${fileData.fileId}`).addEventListener('click', () => {
      downloadAndDecryptFile(fileData.fileId, fileData.name, fileData.type);
    });
  }

  async function downloadAndDecryptFile(fileId, fileName, fileType) {
    const btn = document.getElementById(`dl-btn-${fileId}`);
    btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i>`;
    showToast(`Downloading encrypted packet...`);

    try {
      const response = await fetch(`/api/files/download/${fileId}`, {
        method: 'GET',
        headers: AuthManager.getHeaders()
      });

      if (!response.ok) {
        throw new Error('Download failed');
      }

      showToast('Decrypting download...');
      const encryptedBuffer = await response.arrayBuffer();

      // Decrypt locally using GCM-256 derived key
      const decryptedBuffer = await CryptoEngine.decryptFile(encryptedBuffer, roomKey);

      // Save file
      const blob = new Blob([decryptedBuffer], { type: fileType || 'application/octet-stream' });
      const dlLink = document.createElement('a');
      dlLink.href = URL.createObjectURL(blob);
      dlLink.download = fileName;
      document.body.appendChild(dlLink);
      dlLink.click();
      document.body.removeChild(dlLink);

      btn.innerHTML = `<i class="fa-solid fa-check" style="color: var(--accent-green);"></i>`;
      setTimeout(() => {
        btn.innerHTML = `<i class="fa-solid fa-cloud-arrow-up"></i>`;
      }, 2000);
      showToast('File saved locally.', 'success');
    } catch (err) {
      console.error('File decrypt/download error:', err);
      btn.innerHTML = `<i class="fa-solid fa-circle-exclamation" style="color: var(--accent-red);"></i>`;
      showToast('Failed to decrypt or download file.', 'error');
    }
  }

  // --- UI INTERACTION BINDINGS ---
  function initializeUIHandlers() {
    // Copy Room ID to Clipboard
    document.getElementById('copy-room-id').addEventListener('click', () => {
      navigator.clipboard.writeText(roomId).then(() => {
        showToast('Room ID copied to clipboard.', 'success');
      }).catch(e => {
        console.warn('Clipboard write failed:', e);
      });
    });

    // Mute Microphone
    const micBtn = document.getElementById('toggle-mic');
    const micIcon = document.getElementById('mic-icon');
    micBtn.addEventListener('click', () => {
      isAudioEnabled = !isAudioEnabled;
      if (localStream && localStream.getAudioTracks().length > 0) {
        localStream.getAudioTracks()[0].enabled = isAudioEnabled;
      }
      
      if (isAudioEnabled) {
        micBtn.classList.add('active');
        micIcon.className = 'fa-solid fa-microphone';
        document.getElementById('local-mic-muted-icon').style.display = 'none';
      } else {
        micBtn.classList.remove('active');
        micIcon.className = 'fa-solid fa-microphone-slash';
        document.getElementById('local-mic-muted-icon').style.display = 'flex';
      }
    });

    // Camera On/Off
    const camBtn = document.getElementById('toggle-cam');
    const camIcon = document.getElementById('cam-icon');
    camBtn.addEventListener('click', () => {
      isVideoEnabled = !isVideoEnabled;
      if (localStream && localStream.getVideoTracks().length > 0) {
        localStream.getVideoTracks()[0].enabled = isVideoEnabled;
      }
      
      if (isVideoEnabled) {
        camBtn.classList.add('active');
        camIcon.className = 'fa-solid fa-video';
      } else {
        camBtn.classList.remove('active');
        camIcon.className = 'fa-solid fa-video-slash';
      }
    });

    // Share Screen Toggle
    const screenBtn = document.getElementById('toggle-screen');
    screenBtn.addEventListener('click', async () => {
      if (!isScreenSharing) {
        try {
          showToast('Sharing screen...', 'success');
          localScreenStream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
          isScreenSharing = true;
          screenBtn.classList.add('active');

          const screenTrack = localScreenStream.getVideoTracks()[0];

          // Replace track in all peer connections
          peers.forEach(peer => {
            const sender = peer.connection.getSenders().find(s => s.track.kind === 'video');
            if (sender) {
              sender.replaceTrack(screenTrack);
            }
          });

          // Show local screenshare stream (or keep camera locally, standard conferencing shows screenshare stream locally too)
          const localVideo = document.getElementById('local-video');
          const localVideoContainer = document.getElementById('local-video-container');
          
          localVideo.srcObject = localScreenStream;
          localVideoContainer.classList.add('screen-share-stream');

          screenTrack.onended = () => {
            stopScreenSharing();
          };
        } catch (e) {
          console.error('Error starting screen share:', e);
          isScreenSharing = false;
          screenBtn.classList.remove('active');
        }
      } else {
        stopScreenSharing();
      }
    });

    function stopScreenSharing() {
      if (!isScreenSharing) return;
      
      isScreenSharing = false;
      screenBtn.classList.remove('active');
      showToast('Stopping screen share.');

      if (localScreenStream) {
        localScreenStream.getTracks().forEach(track => track.stop());
      }

      // Re-enable camera local display
      const localVideo = document.getElementById('local-video');
      const localVideoContainer = document.getElementById('local-video-container');
      localVideo.srcObject = localStream;
      localVideoContainer.classList.remove('screen-share-stream');

      // Restore camera track in active Peer Connections
      if (localStream && localStream.getVideoTracks().length > 0) {
        const cameraTrack = localStream.getVideoTracks()[0];
        peers.forEach(peer => {
          const sender = peer.connection.getSenders().find(s => s.track.kind === 'video');
          if (sender) {
            sender.replaceTrack(cameraTrack);
          }
        });
      }
    }

    // Toggle Whiteboard Pane
    const wbBtn = document.getElementById('toggle-whiteboard');
    wbBtn.addEventListener('click', () => {
      const pane = document.getElementById('whiteboard-pane');
      if (pane.style.display === 'flex') {
        pane.style.display = 'none';
        wbBtn.classList.remove('active');
      } else {
        pane.style.display = 'flex';
        wbBtn.classList.add('active');
        
        // Recalculate size of canvas container bounding client rect when revealed
        if (whiteboard) {
          // Responsive fit: canvas coordinates are fixed, but layout resizing takes place
        }
      }
    });

    // Toggle Collaboration Sidebar
    const chatBtn = document.getElementById('toggle-chat');
    chatBtn.addEventListener('click', () => {
      const sidebar = document.getElementById('sidebar-collaboration');
      sidebar.classList.toggle('open');
      chatBtn.classList.toggle('active');
    });

    // Tab buttons handling
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        tabButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const activeTabId = `tab-${btn.dataset.tab}`;
        const tabContents = document.querySelectorAll('.tab-content');
        tabContents.forEach(c => {
          if (c.id === activeTabId) {
            c.classList.add('active');
          } else {
            c.classList.remove('active');
          }
        });
      });
    });

    // Leave Room
    document.getElementById('leave-room').addEventListener('click', () => {
      if (confirm('Are you sure you want to disconnect from this room session?')) {
        cleanupAndExit();
      }
    });
  }

  function cleanupAndExit() {
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    if (localScreenStream) {
      localScreenStream.getTracks().forEach(track => track.stop());
    }
    peers.forEach(peer => {
      if (peer.connection) peer.connection.close();
    });
    peers.clear();
    if (socket) {
      socket.disconnect();
    }
    // Delete room session details but preserve user login token
    sessionStorage.removeItem('rtc_room_id');
    sessionStorage.removeItem('rtc_room_pwd');
    
    window.location.href = 'index.html';
  }

  // --- GENERAL DOM HELPERS ---
  function showToast(message, type = 'info') {
    const feed = document.getElementById('toast-feed');
    const toast = document.createElement('div');
    toast.className = 'toast glass-panel';
    
    let iconClass = 'fa-circle-info';
    let iconColor = 'var(--accent-purple)';
    
    if (type === 'success') {
      iconClass = 'fa-circle-check';
      iconColor = 'var(--accent-green)';
    } else if (type === 'error') {
      iconClass = 'fa-triangle-exclamation';
      iconColor = 'var(--accent-red)';
    }

    toast.innerHTML = `
      <i class="fa-solid ${iconClass}" style="color: ${iconColor};"></i>
      <span>${message}</span>
    `;

    feed.appendChild(toast);
    setTimeout(() => {
      toast.style.animation = 'slide-in 0.3s cubic-bezier(0.16, 1, 0.3, 1) reverse forwards';
      setTimeout(() => {
        toast.remove();
      }, 300);
    }, 4000);
  }

  function updateActivePeersList() {
    const list = document.getElementById('active-users-list');
    
    // Clear dynamic peers first (keep the first 'You' card)
    const items = list.querySelectorAll('.user-item');
    items.forEach((item, index) => {
      if (index > 0) item.remove();
    });

    // Re-add active peers
    peers.forEach((peerObj, socketId) => {
      const item = document.createElement('div');
      item.className = 'user-item';
      
      const letter = peerObj.username.substring(0,1).toUpperCase();

      item.innerHTML = `
        <div class="user-item-info">
          <div class="avatar" style="width: 28px; height: 28px; font-size: 0.75rem; background: linear-gradient(135deg, var(--accent-blue) 0%, var(--accent-cyan) 100%);">${letter}</div>
          <span style="font-size: 0.9rem;">${peerObj.username}</span>
        </div>
        <div class="user-status" style="background-color: var(--accent-cyan);"></div>
      `;
      list.appendChild(item);
    });
  }

  function escapeHtml(text) {
    const map = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
  }

  function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
});
