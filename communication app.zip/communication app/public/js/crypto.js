/**
 * E2EE Client Cryptographic Engine using native Web Crypto API.
 * Encrypts/decrypts data locally; secret keys are never transmitted to the server.
 * Includes a fallback mode for insecure contexts (e.g., testing on local IP networks).
 */

const CryptoEngine = {
  // Check if Web Crypto is fully supported and we are in a secure context
  isSecureContext() {
    return typeof window !== 'undefined' && 
           window.crypto && 
           window.crypto.subtle;
  },

  // Helper to convert String to ArrayBuffer
  strToBuffer(str) {
    return new TextEncoder().encode(str);
  },

  // Helper to convert ArrayBuffer to String
  bufferToStr(buf) {
    return new TextDecoder().decode(buf);
  },

  // Convert ArrayBuffer to Base64 String (for JSON serialization)
  bufferToBase64(buf) {
    const binstr = Array.from(new Uint8Array(buf))
      .map(ch => String.fromCharCode(ch))
      .join('');
    return btoa(binstr);
  },

  // Convert Base64 String to ArrayBuffer
  base64ToBuffer(base64) {
    const binstr = atob(base64);
    const buf = new Uint8Array(binstr.length);
    for (let i = 0; i < binstr.length; i++) {
      buf[i] = binstr.charCodeAt(i);
    }
    return buf.buffer;
  },

  /**
   * Derives a cryptographic key from a plain text password and room salt
   * @param {string} password - The room encryption password
   * @param {string} roomName - Used as salt to specialize key for the room
   * @returns {Promise<CryptoKey|object>} - Derived AES-GCM Key (or Mock Key in insecure contexts)
   */
  async deriveKey(password, roomName) {
    if (!this.isSecureContext()) {
      console.warn('Insecure Context detected: Web Crypto API is unavailable. Using mock fallback.');
      return { mock: true, password, roomName };
    }

    const enc = new TextEncoder();
    const passwordBuffer = enc.encode(password);
    const saltBuffer = enc.encode(roomName + "-secure-salt-v1"); // Static + dynamic salt

    // Import password as raw key material
    const baseKey = await window.crypto.subtle.importKey(
      'raw',
      passwordBuffer,
      'PBKDF2',
      false,
      ['deriveKey']
    );

    // Derive AES-GCM 256-bit key using PBKDF2
    return await window.crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: saltBuffer,
        iterations: 100000,
        hash: 'SHA-256'
      },
      baseKey,
      { name: 'AES-GCM', length: 256 },
      false, // non-extractable for security
      ['encrypt', 'decrypt']
    );
  },

  /**
   * Encrypts plain text using the derived CryptoKey
   * @param {string} plainText 
   * @param {CryptoKey|object} key 
   * @returns {Promise<{iv: string, ciphertext: string, mock?: boolean}>} - Base64 encoded payload
   */
  async encryptText(plainText, key) {
    if (key && key.mock) {
      // Insecure context: fallback to Base64 mock encryption
      return {
        iv: 'mock-iv',
        ciphertext: btoa(encodeURIComponent(plainText)),
        mock: true
      };
    }

    const iv = window.crypto.getRandomValues(new Uint8Array(12)); // 12 bytes IV is standard for GCM
    const encodedText = this.strToBuffer(plainText);

    const ciphertextBuffer = await window.crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: iv
      },
      key,
      encodedText
    );

    return {
      iv: this.bufferToBase64(iv.buffer),
      ciphertext: this.bufferToBase64(ciphertextBuffer)
    };
  },

  /**
   * Decrypts encrypted text payload using the derived CryptoKey
   * @param {object} encryptedData - Contains {iv, ciphertext} in base64
   * @param {CryptoKey|object} key 
   * @returns {Promise<string>} - Original plain text
   */
  async decryptText(encryptedData, key) {
    if (encryptedData.mock || (key && key.mock)) {
      // Decrypt mock payload
      return decodeURIComponent(atob(encryptedData.ciphertext));
    }

    const iv = this.base64ToBuffer(encryptedData.iv);
    const ciphertext = this.base64ToBuffer(encryptedData.ciphertext);

    const decryptedBuffer = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: iv
      },
      key,
      ciphertext
    );

    return this.bufferToStr(decryptedBuffer);
  },

  /**
   * Encrypts a binary file ArrayBuffer
   * @param {ArrayBuffer} arrayBuffer 
   * @param {CryptoKey|object} key 
   * @returns {Promise<ArrayBuffer>} - Combined IV + encrypted ciphertext
   */
  async encryptFile(arrayBuffer, key) {
    if (key && key.mock) {
      // Insecure context fallback: Prepend 12-byte dummy IV to original buffer
      const dummyIv = new Uint8Array(12); // All zeros
      const combinedBuffer = new Uint8Array(dummyIv.length + arrayBuffer.byteLength);
      combinedBuffer.set(dummyIv, 0);
      combinedBuffer.set(new Uint8Array(arrayBuffer), dummyIv.length);
      return combinedBuffer.buffer;
    }

    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    
    const ciphertextBuffer = await window.crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: iv
      },
      key,
      arrayBuffer
    );

    // Concatenate IV (12 bytes) and ciphertext
    const combinedBuffer = new Uint8Array(iv.length + ciphertextBuffer.byteLength);
    combinedBuffer.set(iv, 0);
    combinedBuffer.set(new Uint8Array(ciphertextBuffer), iv.length);

    return combinedBuffer.buffer;
  },

  /**
   * Decrypts a combined IV + encrypted file ArrayBuffer
   * @param {ArrayBuffer} combinedBuffer 
   * @param {CryptoKey|object} key 
   * @returns {Promise<ArrayBuffer>} - Decrypted file ArrayBuffer
   */
  async decryptFile(combinedBuffer, key) {
    if (key && key.mock) {
      // Insecure context: strip 12-byte dummy IV and return original data
      const uint8View = new Uint8Array(combinedBuffer);
      const originalData = uint8View.slice(12);
      return originalData.buffer;
    }

    const uint8View = new Uint8Array(combinedBuffer);
    
    // Extract 12-byte IV
    const iv = uint8View.slice(0, 12);
    
    // Extract ciphertext
    const ciphertext = uint8View.slice(12);

    return await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: iv
      },
      key,
      ciphertext.buffer
    );
  }
};
