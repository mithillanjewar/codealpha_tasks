/**
 * Collaborative Whiteboard Manager.
 * Maps all drawing coordinates to a logical 1200x800 resolution
 * to ensure drawings scale correctly on different screens.
 */

class WhiteboardManager {
  constructor(canvasId, onDrawCallback, onClearCallback) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas.getContext('2d');
    this.onDraw = onDrawCallback;
    this.onClear = onClearCallback;

    // Logical canvas resolution for cross-device consistency
    this.logicalWidth = 1200;
    this.logicalHeight = 800;
    
    this.canvas.width = this.logicalWidth;
    this.canvas.height = this.logicalHeight;

    // Default brush settings
    this.color = '#ffffff';
    this.brushSize = 4;
    this.isEraser = false;
    
    // Draw state
    this.isDrawing = false;
    this.lastX = 0;
    this.lastY = 0;

    this.initListeners();
    this.clearLocal();
  }

  // Set brush color
  setColor(color) {
    this.isEraser = false;
    this.color = color;
  }

  // Set brush thickness
  setBrushSize(size) {
    this.brushSize = size;
  }

  // Enable/disable eraser mode
  setEraser(enabled) {
    this.isEraser = enabled;
  }

  // Convert screen coordinates to logical coordinates
  getLogicalCoords(e) {
    const rect = this.canvas.getBoundingClientRect();
    let clientX, clientY;

    // Support touch devices
    if (e.touches && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    // Map screen pixel to canvas logical coordinate space
    const x = ((clientX - rect.left) / rect.width) * this.logicalWidth;
    const y = ((clientY - rect.top) / rect.height) * this.logicalHeight;

    return { x, y };
  }

  initListeners() {
    // Mouse Events
    this.canvas.addEventListener('mousedown', (e) => this.startDrawing(e));
    this.canvas.addEventListener('mousemove', (e) => this.draw(e));
    this.canvas.addEventListener('mouseup', () => this.stopDrawing());
    this.canvas.addEventListener('mouseout', () => this.stopDrawing());

    // Touch Events for Mobile/Tablets
    this.canvas.addEventListener('touchstart', (e) => {
      e.preventDefault();
      this.startDrawing(e);
    });
    this.canvas.addEventListener('touchmove', (e) => {
      e.preventDefault();
      this.draw(e);
    });
    this.canvas.addEventListener('touchend', () => this.stopDrawing());
  }

  startDrawing(e) {
    this.isDrawing = true;
    const coords = this.getLogicalCoords(e);
    this.lastX = coords.x;
    this.lastY = coords.y;
  }

  draw(e) {
    if (!this.isDrawing) return;

    const coords = this.getLogicalCoords(e);
    const currentX = coords.x;
    const currentY = coords.y;

    const drawPacket = {
      x0: this.lastX,
      y0: this.lastY,
      x1: currentX,
      y1: currentY,
      color: this.isEraser ? '#1e1e2e' : this.color, // Eraser draws with background color
      size: this.brushSize,
      isEraser: this.isEraser
    };

    // Draw locally
    this.drawSegment(drawPacket);

    // Broadcast to peers
    if (this.onDraw) {
      this.onDraw(drawPacket);
    }

    this.lastX = currentX;
    this.lastY = currentY;
  }

  stopDrawing() {
    this.isDrawing = false;
  }

  /**
   * Draws a single path line segment on the canvas
   */
  drawSegment({ x0, y0, x1, y1, color, size, isEraser }) {
    this.ctx.beginPath();
    this.ctx.moveTo(x0, y0);
    this.ctx.lineTo(x1, y1);
    
    // Set stroke styles
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = size;
    this.ctx.lineCap = 'round';
    this.ctx.lineJoin = 'round';
    
    // If it's erasing, use source-out or background color
    if (isEraser) {
      this.ctx.globalCompositeOperation = 'destination-out';
      // If composite operation fails or is slow, draw with background color
      // In this setup, we use composite destination-out to actually transparentize canvas lines
    } else {
      this.ctx.globalCompositeOperation = 'source-over';
    }

    this.ctx.stroke();
    this.ctx.closePath();
    
    // Reset composite operation to default
    this.ctx.globalCompositeOperation = 'source-over';
  }

  // Clear whiteboard locally
  clearLocal() {
    this.ctx.clearRect(0, 0, this.logicalWidth, this.logicalHeight);
    
    // Optional: fill canvas with initial dark background if drawing is not transparent
    // To keep it clean, we clear it so it's fully transparent overlaying elements.
  }

  // Clear whiteboard and notify server
  clear() {
    this.clearLocal();
    if (this.onClear) {
      this.onClear();
    }
  }
}
