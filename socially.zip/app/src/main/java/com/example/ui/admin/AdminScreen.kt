package com.example.ui.admin

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.InstagramViewModel
import com.example.ui.components.AvatarImage
import com.example.ui.components.ProceduralImageRenderer
import com.example.ui.theme.InstaBlue
import com.example.ui.theme.InstaPink

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    viewModel: InstagramViewModel,
    modifier: Modifier = Modifier
) {
    val reportsModel = viewModel.reports

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("admin_dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Toolbar Title
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Icon(Icons.Filled.Shield, contentDescription = null, tint = InstaPink, modifier = Modifier.size(32.dp))
                Column {
                    Text(text = "Picstagram Moderation", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Review flags, manage content, ban toxic accounts", fontSize = 11.sp, color = Color.Gray)
                }
            }
            Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)
        }

        // Section 1: Traffic Analytics Procedural Canvas Graph
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Platform Growth (DUMMY METRICS)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Filled.Leaderboard, null, tint = InstaBlue, modifier = Modifier.size(16.dp))
                            Text(text = "+15% active", fontSize = 11.sp, color = Color.LightGray, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    // Pure custom drawn graphics line chart
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                    ) {
                        val width = size.width
                        val height = size.height
                        val points = listOf(
                            Offset(width * 0.05f, height * 0.8f),
                            Offset(width * 0.2f, height * 0.72f),
                            Offset(width * 0.4f, height * 0.55f),
                            Offset(width * 0.6f, height * 0.62f),
                            Offset(width * 0.8f, height * 0.3f),
                            Offset(width * 0.95f, height * 0.15f)
                        )

                        // Draw Grid lines
                        drawLine(Color.Gray.copy(alpha = 0.1f), Offset(0f, height * 0.5f), Offset(width, height * 0.5f))
                        drawLine(Color.Gray.copy(alpha = 0.1f), Offset(0f, height * 0.9f), Offset(width, height * 0.9f))

                        // Connect dots via smooth curve path lines
                        val path = Path().apply {
                            moveTo(points.first().x, points.first().y)
                            for (i in 1..points.lastIndex) {
                                val prev = points[i - 1]
                                val curr = points[i]
                                cubicTo(
                                    (prev.x + curr.x) / 2, prev.y,
                                    (prev.x + curr.x) / 2, curr.y,
                                    curr.x, curr.y
                                )
                            }
                        }

                        // Draw glowing gradient underneath curve line path
                        drawPath(
                            path = path,
                            brush = Brush.verticalGradient(listOf(InstaPink.copy(alpha = 0.5f), Color.Transparent)),
                            style = Stroke(width = 6f)
                        )

                        // Draw dot anchors
                        points.forEach { pt ->
                            drawCircle(color = InstaPink, radius = 6f, center = pt)
                            drawCircle(color = Color.White, radius = 2f, center = pt)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Mon", fontSize = 10.sp, color = Color.Gray)
                        Text(text = "Wed", fontSize = 10.sp, color = Color.Gray)
                        Text(text = "Fri", fontSize = 10.sp, color = Color.Gray)
                        Text(text = "Today (UTC)", fontSize = 11.sp, color = InstaPink, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Section 2: Active Flagged User Tickets list
        item {
            Text(text = "Unresolved Reports List (${reportsModel.count { !it.isResolved }})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }

        if (reportsModel.isEmpty() || reportsModel.all { it.isResolved }) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "Hooray! No pending moderation flags.", color = Color.Gray)
                }
            }
        } else {
            items(reportsModel.filter { !it.isResolved }) { rep ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AvatarImage(picId = rep.reporter.profilePicture, username = rep.reporter.username, size = 32.dp)
                                Text(text = "Reporter: ${rep.reporter.username}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(InstaPink.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(text = "Flagged User: ${rep.reportedUser.username}", color = InstaPink, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Text(text = "Rationale: \"${rep.reason}\"", fontSize = 13.sp)

                        // Link preview card of post if present
                        if (rep.postReference != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            ) {
                                val firstImg = rep.postReference.imageUrls.split(",").firstOrNull() ?: "default"
                                ProceduralImageRenderer(mediaId = firstImg, modifier = Modifier.fillMaxSize())
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.4f))
                                        .padding(12.dp),
                                    contentAlignment = Alignment.BottomStart
                                ) {
                                    Text(text = "Caption: ${rep.postReference.caption}", color = Color.White, fontSize = 11.sp, maxLines = 2)
                                }
                            }
                        }

                        // Moderation Action Buttons row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // 1. Resolve Report
                            Button(
                                onClick = { viewModel.resolveReport(rep.id) },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).height(36.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = InstaBlue),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Dismiss", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            // 2. Remove Content
                            if (rep.postReference != null) {
                                Button(
                                    onClick = { viewModel.deletePostAdmin(rep.postReference) },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f).height(36.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Icon(Icons.Default.Delete, null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Remove Post", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // 3. Suspend User
                            Button(
                                onClick = { viewModel.banUserAdmin(rep.reportedUser.id) },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).height(36.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(Icons.Default.Block, null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Ban User", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(130.dp))
        }
    }
}
