package com.example.ui.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.InstagramViewModel
import com.example.ui.PostUiModel
import com.example.ui.components.AvatarImage
import com.example.ui.components.ProceduralImageRenderer
import com.example.ui.theme.InstaBlue
import com.example.ui.theme.InstaPink
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: InstagramViewModel,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val allPosts by viewModel.feedPosts.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState(emptyList())
    val myFollowing by viewModel.myFollowing.collectAsState()

    val scope = rememberCoroutineScope()

    // Filter posts and users based on searches
    val filteredUsers = remember(searchQuery, allUsers) {
        if (searchQuery.trim().isEmpty()) emptyList()
        else {
            allUsers.filter {
                it.username.contains(searchQuery, ignoreCase = true) ||
                        it.fullName.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    val filteredPosts = remember(searchQuery, selectedCategory, allPosts) {
        var result = allPosts
        if (searchQuery.trim().isNotEmpty()) {
            result = result.filter {
                it.post.caption.contains(searchQuery, ignoreCase = true) ||
                        it.post.hashtags.contains(searchQuery, ignoreCase = true) ||
                        it.post.location.contains(searchQuery, ignoreCase = true)
            }
        } else if (selectedCategory != "All") {
            val hashtagFilter = when (selectedCategory) {
                "Travel" -> "travel"
                "Food & Baking" -> "baking"
                "Tech" -> "jetpackcompose"
                "Audio Studio" -> "audiophile"
                else -> ""
            }
            if (hashtagFilter.isNotEmpty()) {
                result = result.filter { it.post.hashtags.contains(hashtagFilter, ignoreCase = true) }
            }
        }
        result
    }

    val categories = listOf("All", "Travel", "Food & Baking", "Tech", "Audio Studio")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App search box
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search users, #hashtags, location...", fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("explore_search_input"),
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                focusedBorderColor = Color.Transparent,
                unfocusedBorderColor = Color.Transparent
            ),
            singleLine = true
        )

        if (searchQuery.trim().isNotEmpty()) {
            // Search Results Mode
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                // User Search Results Headers
                if (filteredUsers.isNotEmpty()) {
                    item {
                        Text(
                            text = "Users",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    items(filteredUsers) { user ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.focusOnUser(user.id) }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            AvatarImage(picId = user.profilePicture, username = user.username)
                            Column {
                                Text(
                                    text = user.username,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = user.fullName,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    item {
                        Divider(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            thickness = 0.5.dp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }

                // Post Search Results Headers
                if (filteredPosts.isNotEmpty()) {
                    item {
                        Text(
                            text = "Posts Matching Search",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    items(filteredPosts) { model ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.focusOnUser(model.author.id) }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Box(modifier = Modifier.size(60.dp).clip(RoundedCornerShape(8.dp))) {
                                val firstImg = model.imageUrlList.getOrNull(0) ?: "default"
                                ProceduralImageRenderer(mediaId = firstImg, modifier = Modifier.fillMaxSize())
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = model.author.username,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = model.post.caption,
                                    fontSize = 12.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                if (filteredUsers.isEmpty() && filteredPosts.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(64.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No matches found for \"$searchQuery\"",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        } else {
            // Default Explore Feed Grid Mode
            // C1: Horizon categories scroll bar
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp, start = 16.dp, end = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = cat,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // S2: Dynamic Interactive Explore Grid
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp)
            ) {
                // Suggested Accounts to follow on Picstagram
                val suggestedToFollow = allUsers.filter {
                    it.id != viewModel.currentUserId.value &&
                            !myFollowing.any { active -> active.id == it.id }
                }

                if (suggestedToFollow.isNotEmpty()) {
                    item {
                        Text(
                            text = "Suggested Accounts",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(vertical = 8.dp),
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(bottom = 16.dp)
                        ) {
                            items(suggestedToFollow) { sug ->
                                Card(
                                    modifier = Modifier
                                        .width(135.dp)
                                        .padding(vertical = 4.dp),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        AvatarImage(
                                            picId = sug.profilePicture,
                                            username = sug.username,
                                            size = 56.dp,
                                            modifier = Modifier.clickable { viewModel.focusOnUser(sug.id) }
                                        )

                                        Spacer(modifier = Modifier.height(4.dp))

                                        Text(
                                            text = sug.username,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )

                                        Text(
                                            text = sug.fullName,
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Button(
                                            onClick = { viewModel.toggleFollowUser(sug.id) },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(28.dp),
                                            contentPadding = PaddingValues(0.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = InstaPink),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("Follow", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Header for Explore Grid
                item {
                    Text(
                        text = "Explore Trending",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(vertical = 8.dp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                // Asymmetrical explore style grid pairing
                if (filteredPosts.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(48.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "No posts in \"$selectedCategory\" yet.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    // Group explore photos into custom chunk layers to model asymmetrical grids
                    val chunks = filteredPosts.chunked(3)
                    items(chunks) { chunk ->
                        ExploreGridRow(
                            chunkList = chunk,
                            onPostClick = { model -> viewModel.focusOnUser(model.author.id) }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(120.dp))
                }
            }
        }
    }
}

@Composable
fun ExploreGridRow(
    chunkList: List<PostUiModel>,
    onPostClick: (PostUiModel) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (chunkList.size == 1) {
            ExploreGridItem(
                model = chunkList[0],
                onClick = { onPostClick(chunkList[0]) },
                modifier = Modifier.fillMaxSize()
            )
        } else if (chunkList.size == 2) {
            ExploreGridItem(
                model = chunkList[0],
                onClick = { onPostClick(chunkList[0]) },
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
            ExploreGridItem(
                model = chunkList[1],
                onClick = { onPostClick(chunkList[1]) },
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
        } else {
            // Full 3 items asymmetric explore layout
            ExploreGridItem(
                model = chunkList[0],
                onClick = { onPostClick(chunkList[0]) },
                modifier = Modifier.weight(2f).fillMaxHeight()
            )

            // Right vertical stacked layouts
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExploreGridItem(
                    model = chunkList[1],
                    onClick = { onPostClick(chunkList[1]) },
                    modifier = Modifier.weight(1f).fillMaxWidth()
                )
                ExploreGridItem(
                    model = chunkList[2],
                    onClick = { onPostClick(chunkList[2]) },
                    modifier = Modifier.weight(1f).fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun ExploreGridItem(
    model: PostUiModel,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
    ) {
        ProceduralImageRenderer(
            mediaId = model.imageUrlList.getOrNull(0) ?: "default",
            modifier = Modifier.fillMaxSize()
        )
        
        // Video reels highlight indicator badge
        if (model.post.isVideo) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Video Reel",
                        tint = Color.White,
                        modifier = Modifier.size(10.dp)
                    )
                    Text(
                        text = "REEL",
                        color = Color.White,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}
