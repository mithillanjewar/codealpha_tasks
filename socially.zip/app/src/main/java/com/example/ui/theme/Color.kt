package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val InstaPink = Color(0xFFBA1A1A) // Polished Ruby Crimson Red for Likes / Active Heart
val InstaOrange = Color(0xFFE57373) // Classy Coral Accent
val InstaYellow = Color(0xFFE0A926) // Polished Gold/Bookmark
val InstaPurple = Color(0xFF6750A4) // core MD3 Royal Purple
val InstaBlue = Color(0xFF6750A4) // MD3 Royal Purple for primary active links/bubbles

val DarkBackground = Color(0xFF141218)
val DarkSurface = Color(0xFF1C1B1F)
val DarkSurfaceVariant = Color(0xFF2B2930)
val DarkOnSurface = Color(0xFFE6E1E5)

val LightBackground = Color(0xFFFDF7FF) // Lavender off-white space
val LightSurface = Color(0xFFFFFFFF) // Elevated pure white cards
val LightSurfaceVariant = Color(0xFFF3EDF7) // Soft tint container
val LightOnSurface = Color(0xFF1C1B1F)

val StoryGradient = listOf(Color(0xFF6750A4), Color(0xFFE91E63), Color(0xFFFFD600))
