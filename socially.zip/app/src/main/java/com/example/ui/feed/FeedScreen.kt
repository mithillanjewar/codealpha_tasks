package com.example.ui.feed

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.*
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.text.style.TextAlign

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun FeedScreen(
    viewModel: InstagramViewModel,
    modifier: Modifier = Modifier
) {
    val posts by viewModel.feedPosts.collectAsState()
    val stories by viewModel.activeStories.collectAsState()
    val unreadNotifs by viewModel.unreadNotificationsCount.collectAsState()
    val savedIds by viewModel.savedPostIds.collectAsState()
    val allUsersList by viewModel.allUsers.collectAsState(emptyList())

    val scope = rememberCoroutineScope()

    // Comment Sheet State
    var showCommentSheetForPostId by remember { mutableStateOf<Long?>(null) }
    var currentCommentText by remember { mutableStateOf("") }

    // Share Modal State
    var showShareModalForPostId by remember { mutableStateOf<Long?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header: Icon + Logo + Notification/Direct Messages triggers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Socially",
                    fontSize = 26.sp,
                    fontFamily = FontFamily.Serif,
                    fontStyle = FontStyle.Italic,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Notification Bell indicator
                    Box(
                        modifier = Modifier.clickable { viewModel.navigateToTab("notifications") }
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            modifier = Modifier.size(28.dp),
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                        if (unreadNotifs > 0) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .align(Alignment.TopEnd)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.error)
                            )
                        }
                    }

                    // Direct Messages inbox link
                    Box(
                        modifier = Modifier.clickable { viewModel.navigateToTab("messages") }
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ChatBubbleOutline,
                            contentDescription = "Direct Messages",
                            modifier = Modifier.size(26.dp),
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }

            Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)

            // Content Rows
            LazyColumn(
                modifier = Modifier.fillMaxSize()
            ) {
                // S1: Stories Row
                item {
                    if (stories.isNotEmpty()) {
                        StoriesRow(
                            storiesList = stories,
                            onStoryClick = { selected ->
                                viewModel.openStories(listOf(selected))
                            }
                        )
                        Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)
                    }
                }

                // S2: Feed Cards list
                if (posts.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(64.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.PhotoCamera,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Your feed is empty.",
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Create a post or follow others to begin!",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                } else {
                    items(posts, key = { it.post.id }) { postModel ->
                        FeedCardItem(
                            model = postModel,
                            isSaved = savedIds.contains(postModel.post.id),
                            onUserClick = { viewModel.focusOnUser(postModel.author.id) },
                            onLikeClick = { viewModel.toggleLikePost(postModel.post.id) },
                            onCommentClick = { showCommentSheetForPostId = postModel.post.id },
                            onSaveClick = { viewModel.toggleSavePost(postModel.post.id) },
                            onShareClick = { showShareModalForPostId = postModel.post.id }
                        )
                    }
                }

                // Spacing below the lazycolumn
                item {
                    Spacer(modifier = Modifier.height(120.dp))
                }
            }
        }

        // Standard Comment Bottom Sheet
        if (showCommentSheetForPostId != null) {
            val postId = showCommentSheetForPostId!!
            val postModel = posts.find { it.post.id == postId }
            val commentsFlow = viewModel.repository.commentDao.getCommentsByPostIdFlow(postId).collectAsState(emptyList())

            ModalBottomSheet(
                onDismissRequest = { showCommentSheetForPostId = null },
                containerColor = MaterialTheme.colorScheme.surface,
                dragHandle = { BottomSheetDefaults.DragHandle() }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .imePadding()
                ) {
                    Text(
                        text = "Comments",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)

                    // Scrollable comments list
                    Box(
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .heightIn(max = 350.dp)
                    ) {
                        if (commentsFlow.value.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(48.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No comments yet. Start the conversation!",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 14.sp
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                items(commentsFlow.value) { comment ->
                                    val commenter = allUsersList.find { it.id == comment.userId }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        AvatarImage(
                                            picId = commenter?.profilePicture ?: "grad_sky",
                                            username = commenter?.username ?: "anon",
                                            size = 36.dp
                                        )

                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = commenter?.username ?: "deleted",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "2h",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Text(
                                                text = comment.commentText,
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                modifier = Modifier.padding(top = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Input Text Row
                    Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = currentCommentText,
                            onValueChange = { currentCommentText = it },
                            placeholder = { Text("Add a comment...", fontSize = 14.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(24.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.background,
                                unfocusedContainerColor = MaterialTheme.colorScheme.background,
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent
                            ),
                            singleLine = true
                        )

                        Text(
                            text = "Post",
                            color = if (currentCommentText.trim().isNotEmpty()) InstaPink else Color.Gray,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable {
                                    if (currentCommentText.trim().isNotEmpty()) {
                                        viewModel.addComment(postId, currentCommentText.trim())
                                        currentCommentText = ""
                                    }
                                }
                                .padding(8.dp)
                        )
                    }
                }
            }
        }

        // Custom Share Post Modal Dialog
        if (showShareModalForPostId != null) {
            val postId = showShareModalForPostId!!
            val otherFriends = allUsersList.filter { it.id != viewModel.currentUserId.value }

            AlertDialog(
                onDismissRequest = { showShareModalForPostId = null },
                confirmButton = {},
                dismissButton = {},
                title = {
                    Text(
                        text = "Share Post",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Suggested Friends to DM:",
                            fontSize = 13.sp,
                            modifier = Modifier.padding(bottom = 12.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.heightIn(max = 245.dp)
                        ) {
                            items(otherFriends) { fd ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable {
                                            viewModel.openChatWithUser(fd.id)
                                            viewModel.sendDirectMessage(
                                                messageText = "Check out this post from Picstagram! (POST_ID: $postId)",
                                                imageUrl = null
                                            )
                                            showShareModalForPostId = null
                                        }
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    AvatarImage(picId = fd.profilePicture, username = fd.username)
                                    Column {
                                        Text(text = fd.username, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            text = fd.fullName,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.weight(1f))
                                    Icon(
                                        imageVector = Icons.Default.Send,
                                        contentDescription = "Send",
                                        tint = InstaBlue,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun StoriesRow(
    storiesList: List<StoryUiModel>,
    onStoryClick: (StoryUiModel) -> Unit
) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("stories_row")
            .padding(vertical = 12.dp, horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items(storiesList) { storyModel ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable { onStoryClick(storyModel) }
            ) {
                // Story colorful circular border ring
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(StoryGradient)
                        )
                        .padding(3.dp)
                        .clip(CircleShape)
                        .background(Color.Black)
                        .padding(2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AvatarImage(
                        picId = storyModel.author.profilePicture,
                        username = storyModel.author.username,
                        size = 64.dp
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = storyModel.author.username,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(72.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FeedCardItem(
    model: PostUiModel,
    isSaved: Boolean,
    onUserClick: () -> Unit,
    onLikeClick: () -> Unit,
    onCommentClick: () -> Unit,
    onSaveClick: () -> Unit,
    onShareClick: () -> Unit
) {
    var heartAnimationTrigger by remember { mutableStateOf(false) }
    var currentCarouselIndex by remember { mutableStateOf(0) }

    val coroutineScope = rememberCoroutineScope()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .testTag("feed_card_item_${model.post.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column {
            // User Meta Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .clickable { onUserClick() },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AvatarImage(
                    picId = model.author.profilePicture,
                    username = model.author.username,
                    size = 40.dp
                )

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = model.author.username,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (model.author.id == 1L) { // Me / Admin
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Verified",
                                tint = InstaBlue,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    if (model.post.location.isNotEmpty()) {
                        Text(
                            text = model.post.location,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Image view with swipe carousel pager and double tap like handler
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onDoubleTap = {
                                if (!model.isLiked) {
                                    onLikeClick()
                                }
                                heartAnimationTrigger = true
                            }
                        )
                    }
            ) {
                if (model.post.isVideo) {
                    VideoPlayerRenderer(
                        videoUrl = model.post.videoUrl,
                        modifier = Modifier.fillMaxSize(),
                        maxDurationMs = model.post.videoDurationMs
                    )
                } else {
                    // Procedural Drawing Image
                    val currentImageId = model.imageUrlList.getOrNull(currentCarouselIndex) ?: "default"
                    ProceduralImageRenderer(mediaId = currentImageId, modifier = Modifier.fillMaxSize())
                }

                // Carousel Dots Indicator if multiple images
                if (model.imageUrlList.size > 1) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(12.dp)
                            .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        model.imageUrlList.forEachIndexed { idx, _ ->
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (idx == currentCarouselIndex) Color.White else Color.Gray)
                                    .clickable { currentCarouselIndex = idx }
                            )
                        }
                    }

                    // Floating carousel side button controls
                    if (currentCarouselIndex > 0) {
                        IconButton(
                            onClick = { currentCarouselIndex-- },
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(8.dp)
                                .background(Color.Black.copy(alpha = 0.3f), CircleShape)
                        ) {
                            Icon(Icons.Default.ArrowBackIosNew, null, tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                    if (currentCarouselIndex < model.imageUrlList.lastIndex) {
                        IconButton(
                            onClick = { currentCarouselIndex++ },
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(8.dp)
                                .background(Color.Black.copy(alpha = 0.3f), CircleShape)
                        ) {
                            Icon(Icons.Default.ArrowForwardIos, null, tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                }

                // Centered Double Tap Giant heart animation overlay
                androidx.compose.animation.AnimatedVisibility(
                    visible = heartAnimationTrigger,
                    enter = scaleIn(animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn(),
                    exit = scaleOut() + fadeOut(),
                    modifier = Modifier.align(Alignment.Center)
                ) {
                    LaunchedEffect(heartAnimationTrigger) {
                        if (heartAnimationTrigger) {
                            delay(800)
                            heartAnimationTrigger = false
                        }
                    }
                    Icon(
                        imageVector = Icons.Filled.Favorite,
                        contentDescription = "Loved",
                        tint = Color.White,
                        modifier = Modifier.size(96.dp)
                    )
                }
            }

            // Interactive Bottom Buttons Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Like Button
                IconButton(onClick = { onLikeClick() }) {
                    Icon(
                        imageVector = if (model.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Like Post",
                        tint = if (model.isLiked) InstaPink else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(28.dp)
                    )
                }

                // Comment Button
                IconButton(onClick = { onCommentClick() }) {
                    Icon(
                        imageVector = Icons.Outlined.ChatBubbleOutline,
                        contentDescription = "Comments",
                        modifier = Modifier.size(25.dp),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Share Button (Paper Plane)
                IconButton(onClick = { onShareClick() }) {
                    Icon(
                        imageVector = Icons.Outlined.Send,
                        contentDescription = "Share",
                        modifier = Modifier.size(25.dp),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Bookmark/Save Button
                IconButton(onClick = { onSaveClick() }) {
                    Icon(
                        imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = "Save Post",
                        tint = if (isSaved) InstaYellow else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            // Likes Metrics & Captions Block
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                if (model.likesCount > 0) {
                    Text(
                        text = "${model.likesCount} likes",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // User Caption
                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = "${model.author.username} ",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = model.post.caption,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Comments Counter expand button
                if (model.commentsCount > 0) {
                    Text(
                        text = "View all ${model.commentsCount} comments",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .clickable { onCommentClick() }
                            .padding(vertical = 4.dp)
                    )
                } else {
                    Text(
                        text = "Add a comment...",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .clickable { onCommentClick() }
                            .padding(vertical = 4.dp)
                    )
                }
            }
        }
    }
}
