package com.example.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.InstagramViewModel
import com.example.ui.components.AvatarImage
import com.example.ui.components.ProceduralImageRenderer
import com.example.ui.theme.InstaBlue
import com.example.ui.theme.InstaPink
import com.example.ui.theme.InstaYellow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: InstagramViewModel,
    isViewingOther: Boolean = false,
    modifier: Modifier = Modifier
) {
    // Collect active user info
    val me by viewModel.currentUser.collectAsState(null)
    val other by viewModel.focusedUser.collectAsState(null)

    val activeUser = if (isViewingOther) other else me

    val allPosts by viewModel.feedPosts.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState(emptyList())

    val isAdmin by viewModel.isAdminMode.collectAsState()

    val scope = rememberCoroutineScope()

    // Form inputs for editingprofile modal
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var editFullName by remember { mutableStateOf("") }
    var editBio by remember { mutableStateOf("") }
    var editWebsite by remember { mutableStateOf("") }
    var editIsPrivate by remember { mutableStateOf(false) }

    // Follower list viewers modal states
    var showContactsModalTitle by remember { mutableStateOf<String?>(null) } // "Followers" or "Following"

    // Tabs inside profile page: 0 -> Grid Posts, 1 -> Saved Bookmarks
    var selectedTabIdx by remember { mutableStateOf(0) }

    if (activeUser == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    // Filter relevant metrics of this profile
    val userPosts = remember(allPosts, activeUser) {
        allPosts.filter { it.post.userId == activeUser.id }
    }

    val savedPosts = remember(allPosts, viewModel.savedPostIds.collectAsState().value, activeUser) {
        allPosts.filter { viewModel.savedPostIds.value.contains(it.post.id) }
    }

    // Resolving followers/following counts dynamically
    val followerListFlow = remember(activeUser, allUsers) {
        viewModel.repository.followerDao.getFollowersFlow(activeUser.id)
    }.collectAsState(emptyList())

    val followingListFlow = remember(activeUser, allUsers) {
        viewModel.repository.followerDao.getFollowingFlow(activeUser.id)
    }.collectAsState(emptyList())

    val isFollowingOther = remember(activeUser) {
        viewModel.repository.followerDao.getFollowersFlow(activeUser.id)
    }.collectAsState(emptyList()).value.any { it.followerId == me?.id }

    val isPendingOther = remember(activeUser) {
        viewModel.repository.followerDao.getPendingRequestsFlow(activeUser.id)
    }.collectAsState(emptyList()).value.any { it.followerId == me?.id }

    val showPrivateLock = isViewingOther && activeUser.isPrivate && !isFollowingOther

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 120.dp)
            .testTag("profile_screen_layout")
    ) {
        // Upper Profile toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (isViewingOther) {
                    IconButton(onClick = { viewModel.navigateToTab("feed") }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
                Text(
                    text = activeUser.username,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                if (activeUser.id == 1L) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Verified",
                        tint = InstaBlue,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!isViewingOther) {
                    // Admin Toggle Quick Tab shortcut
                    IconButton(onClick = { viewModel.toggleAdminMode() }) {
                        Icon(
                            imageVector = if (isAdmin) Icons.Filled.Shield else Icons.Outlined.Shield,
                            contentDescription = "Admin Mod Panel Toggle",
                            tint = if (isAdmin) InstaPink else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Logout Action button icon
                    IconButton(onClick = { viewModel.logout() }) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = "Log out",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                } else {
                    IconButton(onClick = { viewModel.openChatWithUser(activeUser.id) }) {
                        Icon(
                            imageVector = Icons.Outlined.Chat,
                            contentDescription = "Direct DM",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }
        }

        // Section details: Photo Avatar + Analytics Grid numbers count
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box {
                AvatarImage(
                    picId = activeUser.profilePicture,
                    username = activeUser.username,
                    size = 80.dp
                )
                if (activeUser.isPrivate) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .align(Alignment.BottomEnd)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(2.dp)
                            .clip(CircleShape)
                            .background(InstaPink),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Lock, null, tint = Color.White, modifier = Modifier.size(12.dp))
                    }
                }
            }

            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                AnalyticsCounterItem(count = userPosts.size, label = "posts")
                AnalyticsCounterItem(
                    count = followerListFlow.value.size,
                    label = "followers",
                    onClick = { showContactsModalTitle = "Followers" }
                )
                AnalyticsCounterItem(
                    count = followingListFlow.value.size,
                    label = "following",
                    onClick = { showContactsModalTitle = "Following" }
                )
            }
        }

        // Bio section detail
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = activeUser.fullName,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = activeUser.bio,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (activeUser.website.isNotEmpty()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = "Link",
                        tint = InstaBlue,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = activeUser.website,
                        fontSize = 13.sp,
                        color = InstaBlue,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable {}
                    )
                }
            }
        }

        // Profile Buttons row: Edit vs Follow/Unfollow
        Spacer(modifier = Modifier.height(20.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (!isViewingOther) {
                Button(
                    onClick = {
                        editFullName = activeUser.fullName
                        editBio = activeUser.bio
                        editWebsite = activeUser.website
                        editIsPrivate = activeUser.isPrivate
                        showEditProfileDialog = true
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .testTag("edit_profile_dialog_trigger"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("Edit Profile", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { viewModel.navigateToTab("messages") },
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("Direct Inbox", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                // Secondary Profile follow/unfollow actions button
                val buttonText = when {
                    isFollowingOther -> "Following"
                    isPendingOther -> "Requested"
                    else -> "Follow"
                }

                val btnBgColor = if (isFollowingOther || isPendingOther) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primary
                val btnFgColor = if (isFollowingOther || isPendingOther) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onPrimary

                Button(
                    onClick = { viewModel.toggleFollowUser(activeUser.id) },
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = btnBgColor, contentColor = btnFgColor),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(text = buttonText, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { viewModel.openChatWithUser(activeUser.id) },
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("Message", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Grid Tabs Selector Row
        TabRow(
            selectedTabIndex = selectedTabIdx,
            containerColor = Color.Transparent,
            divider = { Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp) }
        ) {
            Tab(
                selected = selectedTabIdx == 0,
                onClick = { selectedTabIdx = 0 },
                icon = { Icon(Icons.Default.GridView, contentDescription = "Posts") }
            )
            if (!isViewingOther) {
                Tab(
                    selected = selectedTabIdx == 1,
                    onClick = { selectedTabIdx = 1 },
                    icon = { Icon(Icons.Default.BookmarkBorder, contentDescription = "Saved") }
                )
            }
        }

        // Grid contents view
        if (showPrivateLock) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(48.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    modifier = Modifier.size(48.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "This Account is Private",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Follow this account to inspect posts and stories.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            val gridItems = if (selectedTabIdx == 0) userPosts else savedPosts

            if (gridItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (selectedTabIdx == 0) "No posts yet" else "No saved posts yet",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp
                    )
                }
            } else {
                // Fixed height visual wrapper for profiling grid layouts inside nested viewports
                Box(modifier = Modifier.heightIn(max = 600.dp)) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        contentPadding = PaddingValues(2.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(gridItems) { model ->
                            Box(
                                modifier = Modifier
                                    .aspectRatio(1f)
                                    .clickable { viewModel.navigateToTab("feed") }
                            ) {
                                val firstImg = model.imageUrlList.getOrNull(0) ?: "default"
                                ProceduralImageRenderer(
                                    mediaId = firstImg,
                                    modifier = Modifier.fillMaxSize()
                                )
                                // Overlaid multi carousel indicators
                                if (model.imageUrlList.size > 1) {
                                    Icon(
                                        imageVector = Icons.Default.Layers,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(6.dp)
                                            .size(16.dp)
                                    )
                                }
                                // Overlaid video play indicator badge
                                if (model.post.isVideo) {
                                    Icon(
                                        imageVector = Icons.Default.PlayCircle,
                                        contentDescription = "Video post",
                                        tint = Color.White,
                                        modifier = Modifier
                                            .align(Alignment.TopStart)
                                            .padding(6.dp)
                                            .size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Dialog: Edit Profile Modal
        if (showEditProfileDialog) {
            AlertDialog(
                onDismissRequest = { showEditProfileDialog = false },
                title = { Text("Edit Profile Information", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.editProfile(
                                fullName = editFullName,
                                bio = editBio,
                                website = editWebsite,
                                isPrivate = editIsPrivate
                            )
                            showEditProfileDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Save Details", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditProfileDialog = false }) {
                        Text("Cancel")
                    }
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = editFullName,
                            onValueChange = { editFullName = it },
                            label = { Text("Full Name") },
                            modifier = Modifier.fillMaxWidth().testTag("edit_full_name_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = editBio,
                            onValueChange = { editBio = it },
                            label = { Text("Bio description") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3
                        )

                        OutlinedTextField(
                            value = editWebsite,
                            onValueChange = { editWebsite = it },
                            label = { Text("Active Website URL") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Private Account Lock", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Switch(
                                checked = editIsPrivate,
                                onCheckedChange = { editIsPrivate = it }
                            )
                        }
                    }
                }
            )
        }

        // Dialog: Contacts list viewer modal followings
        if (showContactsModalTitle != null) {
            val title = showContactsModalTitle!!
            val recordsList = if (title == "Followers") {
                followerListFlow.value.mapNotNull { f -> allUsers.find { it.id == f.followerId } }
            } else {
                followingListFlow.value.mapNotNull { f -> allUsers.find { it.id == f.followingId } }
            }

            AlertDialog(
                onDismissRequest = { showContactsModalTitle = null },
                confirmButton = {
                    TextButton(onClick = { showContactsModalTitle = null }) {
                        Text("Close")
                    }
                },
                title = { Text(text = title, fontWeight = FontWeight.Bold) },
                text = {
                    if (recordsList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "No users listed in this section.", color = Color.Gray)
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.heightIn(max = 280.dp)
                        ) {
                            items(recordsList) { cont ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            viewModel.focusOnUser(cont.id)
                                            showContactsModalTitle = null
                                        }
                                        .padding(4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    AvatarImage(picId = cont.profilePicture, username = cont.username, size = 36.dp)
                                    Column {
                                        Text(text = cont.username, fontWeight = FontWeight.SemiBold)
                                        Text(text = cont.fullName, fontSize = 11.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun AnalyticsCounterItem(
    count: Int,
    label: String,
    onClick: (() -> Unit)? = null
) {
    val clickableModifier = if (onClick != null) Modifier.clickable { onClick() } else Modifier
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = clickableModifier.padding(4.dp)
    ) {
        Text(
            text = "$count",
            fontWeight = FontWeight.Black,
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = label,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
