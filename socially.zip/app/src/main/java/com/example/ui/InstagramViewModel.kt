package com.example.ui

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class PostUiModel(
    val post: PostEntity,
    val author: UserEntity,
    val isLiked: Boolean,
    val likesCount: Int,
    val commentsCount: Int,
    val imageUrlList: List<String>
)

data class StoryUiModel(
    val story: StoryEntity,
    val author: UserEntity,
    val isViewed: Boolean = false
)

data class ChatConversation(
    val otherUser: UserEntity,
    val lastMessage: MessageEntity,
    val unreadCount: Int
)

data class ReportUiModel(
    val id: Long,
    val reporter: UserEntity,
    val reportedUser: UserEntity,
    val reason: String,
    val postReference: PostEntity?,
    val isResolved: Boolean = false
)

class InstagramViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = Repository(database)

    // Current Login States
    val currentUser = repository.currentUser
    val currentUserId = repository.currentUserId
    val allUsers = repository.userDao.getAllUsersFlow()

    // Active screen route manager
    private val _currentTab = MutableStateFlow("feed")
    val currentTab: StateFlow<String> = _currentTab.asStateFlow()

    fun navigateToTab(tab: String) {
        _currentTab.value = tab
    }

    // Dynamic Feed Flow
    val feedPosts: StateFlow<List<PostUiModel>> = combine(
        repository.postDao.getAllPostsFlow(),
        repository.userDao.getAllUsersFlow(),
        currentUserId
    ) { posts, users, loggedInId ->
        if (loggedInId == null) return@combine emptyList<PostUiModel>()

        // Prepopulate lists
        posts.map { post ->
            val author = users.find { it.id == post.userId } ?: UserEntity(
                username = "deleted_user",
                fullName = "Deleted User",
                email = "",
                passwordHash = "",
                profilePicture = "grad_sky",
                bio = "",
                website = ""
            )

            // Calculate metrics on the fly using local suspended state or simple lookups
            // (We will resolve likes and comments reactively, since our database is local)
            // To do this reactively in Room, we join or construct combining flows, or we query and update inside Room. 
            // Let's implement a streamlined reactive approach by fetching helper lists directly.
            // Under flow combining:
            PostUiModel(
                post = post,
                author = author,
                isLiked = false, // Will resolve below
                likesCount = 0,
                commentsCount = 0,
                imageUrlList = post.imageUrls.split(",").filter { it.isNotEmpty() }
            )
        }
    }.flatMapLatest { initialList ->
        if (initialList.isEmpty()) return@flatMapLatest flowOf(emptyList())

        // Combine with likes and comment counts reactively!
        val flowList = initialList.map { model ->
            combine(
                repository.likeDao.getPostLikesFlow(model.post.id),
                repository.commentDao.getCommentsCountFlow(model.post.id),
                currentUserId
            ) { likes, commentsCount, loggedInId ->
                val isLiked = likes.any { it.userId == loggedInId }
                model.copy(
                    isLiked = isLiked,
                    likesCount = likes.size,
                    commentsCount = commentsCount
                )
            }
        }
        combine(flowList) { it.toList() }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Video Reels Flow
    val reels: StateFlow<List<PostUiModel>> = feedPosts
        .map { posts -> posts.filter { it.post.isVideo } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Stories Flow
    val activeStories: StateFlow<List<StoryUiModel>> = combine(
        repository.storyDao.getActiveStoriesFlow(),
        repository.userDao.getAllUsersFlow()
    ) { stories, users ->
        stories.mapNotNull { story ->
            val author = users.find { it.id == story.userId } ?: return@mapNotNull null
            StoryUiModel(story, author)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Story Detail view state
    private val _viewingStoryGroup = MutableStateFlow<List<StoryUiModel>?>(null)
    val viewingStoryGroup: StateFlow<List<StoryUiModel>?> = _viewingStoryGroup.asStateFlow()

    fun openStories(stories: List<StoryUiModel>) {
        _viewingStoryGroup.value = stories
    }

    fun closeStories() {
        _viewingStoryGroup.value = null
    }

    // Direct Messages (Chats) Flows
    private val _activeChatUserId = MutableStateFlow<Long?>(null)
    val activeChatUserId: StateFlow<Long?> = _activeChatUserId.asStateFlow()

    // Chat typing simulation state
    private val _isChatPartnerTyping = MutableStateFlow(false)
    val isChatPartnerTyping: StateFlow<Boolean> = _isChatPartnerTyping.asStateFlow()

    val chatMessages: Flow<List<MessageEntity>> = combine(
        currentUserId,
        _activeChatUserId
    ) { loggedInId, activeId ->
        if (loggedInId == null || activeId == null) null
        else Pair(loggedInId, activeId)
    }.flatMapLatest { pair ->
        if (pair == null) flowOf(emptyList())
        else repository.messageDao.getMessagesFlow(pair.first, pair.second)
    }

    val conversationList: StateFlow<List<ChatConversation>> = combine(
        currentUserId,
        repository.messageDao.getAllUserMessagesFlow(0), // Let Room fetch all messages, filter below
        repository.userDao.getAllUsersFlow()
    ) { loggedInId, allMsgs, users ->
        if (loggedInId == null) return@combine emptyList<ChatConversation>()

        val userMessages = allMsgs.filter { it.senderId == loggedInId || it.receiverId == loggedInId }
        val conversationsMap = mutableMapOf<Long, MutableList<MessageEntity>>()

        for (msg in userMessages) {
            val partnerId = if (msg.senderId == loggedInId) msg.receiverId else msg.senderId
            if (partnerId != loggedInId) {
                conversationsMap.getOrPut(partnerId) { mutableListOf() }.add(msg)
            }
        }

        conversationsMap.mapNotNull { (partnerId, msgs) ->
            val otherUser = users.find { it.id == partnerId } ?: return@mapNotNull null
            val lastMsg = msgs.maxByOrNull { it.createdAt } ?: return@mapNotNull null
            val unreadCount = msgs.count { it.receiverId == loggedInId && !it.isRead }

            ChatConversation(otherUser, lastMsg, unreadCount)
        }.sortedByDescending { it.lastMessage.createdAt }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active User Profile Flow (for search clicking/exploring)
    private val _focusedUserId = MutableStateFlow<Long?>(null)
    val focusedUserId: StateFlow<Long?> = _focusedUserId.asStateFlow()

    val focusedUser: Flow<UserEntity?> = _focusedUserId.flatMapLatest { id ->
        if (id == null) flowOf(null)
        else repository.userDao.getUserByIdFlow(id)
    }

    val focusedUserPosts: Flow<List<PostEntity>> = _focusedUserId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList())
        else repository.postDao.getPostsByUserIdFlow(id)
    }

    val focusedUserFollowers: Flow<List<FollowerEntity>> = _focusedUserId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList())
        else repository.followerDao.getFollowersFlow(id)
    }

    val focusedUserFollowing: Flow<List<FollowerEntity>> = _focusedUserId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList())
        else repository.followerDao.getFollowingFlow(id)
    }

    val isFollowingFocusedUser: Flow<Boolean> = combine(
        currentUserId,
        _focusedUserId
    ) { me, other ->
        if (me == null || other == null) false
        else {
            val rec = repository.followerDao.getFollowRecord(me, other)
            rec != null && !rec.isPending
        }
    }

    val isPendingFollowFocusedUser: Flow<Boolean> = combine(
        currentUserId,
        _focusedUserId
    ) { me, other ->
        if (me == null || other == null) false
        else {
            val rec = repository.followerDao.getFollowRecord(me, other)
            rec != null && rec.isPending
        }
    }

    fun focusOnUser(userId: Long) {
        _focusedUserId.value = userId
        navigateToTab("profile_details")
    }

    fun openChatWithUser(userId: Long) {
        _activeChatUserId.value = userId
        viewModelScope.launch {
            val me = currentUserId.value
            if (me != null) {
                repository.messageDao.markMessagesAsRead(me, userId)
            }
        }
        navigateToTab("chat_detail")
    }

    // Notifications Flow
    val notifications: StateFlow<List<NotificationUiModel>> = currentUserId.flatMapLatest { loggedInId ->
        if (loggedInId == null) flowOf(emptyList())
        else {
            combine(
                repository.notificationDao.getNotificationsFlow(loggedInId),
                repository.userDao.getAllUsersFlow()
            ) { notifyList, users ->
                notifyList.map { notif ->
                    val sender = users.find { it.id == notif.senderId } ?: UserEntity(
                        username = "unknown_user",
                        fullName = "Someone",
                        email = "",
                        passwordHash = "",
                        profilePicture = "grad_sky",
                        bio = "",
                        website = ""
                    )
                    NotificationUiModel(notif, sender)
                }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotificationsCount: StateFlow<Int> = currentUserId.flatMapLatest { id ->
        if (id == null) flowOf(0)
        else repository.notificationDao.getUnreadCountFlow(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Admin Dashboard Moderation List
    val reports = mutableStateListOf<ReportUiModel>()
    private val _isAdminMode = MutableStateFlow(false)
    val isAdminMode: StateFlow<Boolean> = _isAdminMode.asStateFlow()

    fun toggleAdminMode() {
        _isAdminMode.value = !_isAdminMode.value
    }

    init {
        // Initialize Admin reporting with 2 mock reports for interactability
        viewModelScope.launch {
            // Wait for DB seed initialization
            delay(1500)
            val usersList = repository.userDao.searchUsers("")
            val jess = usersList.find { it.username == "jess_travels" }
            val alex = usersList.find { it.username == "alex_bakes" }
            val taylor = usersList.find { it.username == "taylor_tunes" }
            val posts = repository.postDao.searchPosts("")

            if (jess != null && alex != null && taylor != null && posts.isNotEmpty()) {
                reports.clear()
                reports.add(
                    ReportUiModel(
                        id = 1L,
                        reporter = alex,
                        reportedUser = taylor,
                        reason = "Taylors's post text is too noisy about audio preamps, it's making pastry chefs hungry for sourdough!",
                        postReference = posts.find { it.userId == taylor.id },
                        isResolved = false
                    )
                )
                reports.add(
                    ReportUiModel(
                        id = 2L,
                        reporter = taylor,
                        reportedUser = jess,
                        reason = "Kyoto photos are too bright, blinding my synthesizer meters in DeX mode.",
                        postReference = posts.find { it.userId == jess.id },
                        isResolved = false
                    )
                )
            }
        }
    }

    // Follower list / Dialog states
    val myFollowers: StateFlow<List<UserEntity>> = currentUserId.flatMapLatest { loggedInId ->
        if (loggedInId == null) flowOf(emptyList())
        else {
            combine(
                repository.followerDao.getFollowersFlow(loggedInId),
                repository.userDao.getAllUsersFlow()
            ) { followersList, all ->
                followersList.mapNotNull { f -> all.find { it.id == f.followerId } }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val myFollowing: StateFlow<List<UserEntity>> = currentUserId.flatMapLatest { loggedInId ->
        if (loggedInId == null) flowOf(emptyList())
        else {
            combine(
                repository.followerDao.getFollowingFlow(loggedInId),
                repository.userDao.getAllUsersFlow()
            ) { followingList, all ->
                followingList.mapNotNull { f -> all.find { it.id == f.followingId } }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingFollowRequests: StateFlow<List<UserEntity>> = currentUserId.flatMapLatest { loggedInId ->
        if (loggedInId == null) flowOf(emptyList())
        else {
            combine(
                repository.followerDao.getPendingRequestsFlow(loggedInId),
                repository.userDao.getAllUsersFlow()
            ) { pendingList, all ->
                pendingList.mapNotNull { f -> all.find { it.id == f.followerId } }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Saved/Bookmarked Posts
    private val _savedPostIds = MutableStateFlow<Set<Long>>(emptySet())
    val savedPostIds: StateFlow<Set<Long>> = _savedPostIds.asStateFlow()

    fun toggleSavePost(postId: Long) {
        val currentSet = _savedPostIds.value.toMutableSet()
        if (currentSet.contains(postId)) {
            currentSet.remove(postId)
        } else {
            currentSet.add(postId)
        }
        _savedPostIds.value = currentSet
    }

    // Interactions
    fun toggleLikePost(postId: Long) {
        viewModelScope.launch {
            val me = currentUserId.value ?: return@launch
            val existingLike = repository.likeDao.getPostLike(me, postId)
            if (existingLike != null) {
                repository.likeDao.deleteLike(existingLike)
            } else {
                repository.likeDao.insertLike(LikeEntity(userId = me, postId = postId))
                // Notify the author
                val post = repository.postDao.getPostById(postId)
                if (post != null && post.userId != me) {
                    repository.notificationDao.insertNotification(
                        NotificationEntity(
                            userId = post.userId,
                            senderId = me,
                            type = "LIKE",
                            referenceId = postId
                        )
                    )
                }
            }
        }
    }

    fun addComment(postId: Long, commentText: String) {
        if (commentText.trim().isEmpty()) return
        viewModelScope.launch {
            val me = currentUserId.value ?: return@launch
            repository.commentDao.insertComment(
                CommentEntity(postId = postId, userId = me, commentText = commentText)
            )
            // Notify the author
            val post = repository.postDao.getPostById(postId)
            if (post != null && post.userId != me) {
                repository.notificationDao.insertNotification(
                    NotificationEntity(
                        userId = post.userId,
                        senderId = me,
                        type = "COMMENT",
                        referenceId = postId
                    )
                )
            }
        }
    }

    fun toggleFollowUser(targetId: Long) {
        viewModelScope.launch {
            val me = currentUserId.value ?: return@launch
            val existingRecord = repository.followerDao.getFollowRecord(me, targetId)
            if (existingRecord != null) {
                // Unfollow
                repository.followerDao.deleteFollow(existingRecord)
            } else {
                val target = repository.userDao.getUserById(targetId) ?: return@launch
                val isPrivate = target.isPrivate
                repository.followerDao.insertFollow(
                    FollowerEntity(followerId = me, followingId = targetId, isPending = isPrivate)
                )
                // Insert notification
                repository.notificationDao.insertNotification(
                    NotificationEntity(
                        userId = targetId,
                        senderId = me,
                        type = if (isPrivate) "FOLLOW_REQUEST" else "FOLLOW",
                        referenceId = me
                    )
                )
            }
        }
    }

    fun acceptFollowRequest(requesterId: Long) {
        viewModelScope.launch {
            val me = currentUserId.value ?: return@launch
            val record = repository.followerDao.getFollowRecord(requesterId, me)
            if (record != null && record.isPending) {
                repository.followerDao.updateFollow(record.copy(isPending = false))
                // Notify them that we accepted
                repository.notificationDao.insertNotification(
                    NotificationEntity(
                        userId = requesterId,
                        senderId = me,
                        type = "FOLLOW",
                        referenceId = me
                    )
                )
            }
        }
    }

    fun declineFollowRequest(requesterId: Long) {
        viewModelScope.launch {
            val me = currentUserId.value ?: return@launch
            val record = repository.followerDao.getFollowRecord(requesterId, me)
            if (record != null) {
                repository.followerDao.deleteFollow(record)
            }
        }
    }

    fun createPost(
        imageUrls: List<String>,
        caption: String,
        location: String,
        hashtags: String,
        isVideo: Boolean = false,
        videoUrl: String = "",
        transcodeResolution: String = "1080p (HQ Original)",
        videoDurationMs: Long = 15000L
    ) {
        viewModelScope.launch {
            val me = currentUserId.value ?: return@launch
            repository.postDao.insertPost(
                PostEntity(
                    userId = me,
                    imageUrls = imageUrls.joinToString(","),
                    caption = caption,
                    location = location,
                    hashtags = hashtags,
                    isVideo = isVideo,
                    videoUrl = videoUrl,
                    transcodeResolution = transcodeResolution,
                    videoDurationMs = videoDurationMs
                )
            )
            _currentTab.value = "feed"
        }
    }

    fun createStory(mediaUrl: String, caption: String) {
        viewModelScope.launch {
            val me = currentUserId.value ?: return@launch
            repository.storyDao.insertStory(
                StoryEntity(
                    userId = me,
                    mediaUrl = mediaUrl,
                    caption = caption
                )
            )
        }
    }

    fun sendDirectMessage(messageText: String, imageUrl: String? = null) {
        val me = currentUserId.value ?: return
        val partnerId = _activeChatUserId.value ?: return
        if (messageText.trim().isEmpty() && imageUrl == null) return

        viewModelScope.launch {
            val msg = MessageEntity(
                senderId = me,
                receiverId = partnerId,
                message = messageText,
                imageUrl = imageUrl,
                isRead = false
            )
            repository.messageDao.insertMessage(msg)

            // Trigger typing simulator & simulated chatbot response
            _isChatPartnerTyping.value = true
            delay(1500) // Realistic typing pause
            _isChatPartnerTyping.value = false

            val replyText = getDynamicChatbotResponse(otherUserId = partnerId, userMessage = messageText)
            val replyMsg = MessageEntity(
                senderId = partnerId,
                receiverId = me,
                message = replyText,
                imageUrl = null,
                isRead = false
            )
            repository.messageDao.insertMessage(replyMsg)

            // Trigger notification
            repository.notificationDao.insertNotification(
                NotificationEntity(
                    userId = me,
                    senderId = partnerId,
                    type = "MESSAGE",
                    referenceId = replyMsg.id,
                    isRead = false
                )
            )
        }
    }

    private fun getDynamicChatbotResponse(otherUserId: Long, userMessage: String): String {
        val lower = userMessage.lowercase()
        return when {
            lower.contains("hello") || lower.contains("hi") || lower.contains("hey") -> {
                "Hey there! Living life, hope your day is going awesome 🌟"
            }
            lower.contains("tokyo") || lower.contains("japan") || lower.contains("travel") -> {
                "Kyoto was absolutely beautiful! I highly recommend checking out Fushimi Inari at dawn, it is majestic!"
            }
            lower.contains("bake") || lower.contains("bread") || lower.contains("croissant") -> {
                "The secret is keeping the hydration percentage high! Let me know if you want me to save a fresh loaf of sourdough for you!"
            }
            lower.contains("code") || lower.contains("android") || lower.contains("jetpack") -> {
                "Compose makes building social media client interfaces look so professional. The smooth state rendering is gorgeous!"
            }
            lower.contains("studio") || lower.contains("guitar") || lower.contains("music") -> {
                "I am combining raw analog sound with modern filters. Sounds absolutely colossal! Want to hear a teaser?"
            }
            lower.contains("cool") || lower.contains("awesome") || lower.contains("nice") -> {
                "Right?! Appreciate you saying that. Let me know when you're around!"
            }
            else -> {
                "That is wonderful! Let's definitely catch up soon and collaborate on some new posts. 📸🚀"
            }
        }
    }

    // Admin Dashboard Actions
    fun resolveReport(reportId: Long) {
        val idx = reports.indexOfFirst { it.id == reportId }
        if (idx != -1) {
            reports[idx] = reports[idx].copy(isResolved = true)
        }
    }

    fun deletePostAdmin(post: PostEntity) {
        viewModelScope.launch {
            repository.postDao.deletePost(post)
            // Remove report associated
            reports.removeAll { it.postReference?.id == post.id }
        }
    }

    fun banUserAdmin(userId: Long) {
        viewModelScope.launch {
            val user = repository.userDao.getUserById(userId)
            if (user != null) {
                // Delete user's posts
                val posts = repository.postDao.searchPosts("")
                posts.filter { it.userId == userId }.forEach {
                    repository.postDao.deletePost(it)
                }
                // We mark user bio as Banned
                repository.userDao.updateUser(user.copy(fullName = "[BANNED USER]", bio = "This user has been suspended by Picstagram Admin moderation.", website = ""))
                // Remove relevant reports
                reports.removeAll { it.reportedUser.id == userId }
            }
        }
    }

    fun clearNotifications() {
        viewModelScope.launch {
            val me = currentUserId.value
            if (me != null) {
                repository.notificationDao.markAllAsRead(me)
            }
        }
    }

    fun editProfile(fullName: String, bio: String, website: String, isPrivate: Boolean) {
        viewModelScope.launch {
            val meUser = repository.userDao.getUserById(currentUserId.value ?: return@launch)
            if (meUser != null) {
                repository.userDao.updateUser(
                    meUser.copy(
                        fullName = fullName,
                        bio = bio,
                        website = website,
                        isPrivate = isPrivate
                    )
                )
            }
        }
    }

    fun logout() {
        repository.logout()
    }
}

data class NotificationUiModel(
    val notification: NotificationEntity,
    val sender: UserEntity
)
