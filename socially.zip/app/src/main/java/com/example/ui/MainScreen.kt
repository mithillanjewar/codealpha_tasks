package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.admin.AdminScreen
import com.example.ui.auth.AuthScreen
import com.example.ui.components.AvatarImage
import com.example.ui.components.ProceduralImageRenderer
import com.example.ui.create.CreatePostScreen
import com.example.ui.feed.FeedScreen
import com.example.ui.messages.MessagesScreen
import com.example.ui.notifications.NotificationsScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.reels.ReelsScreen
import com.example.ui.search.SearchScreen
import com.example.ui.theme.InstaBlue
import com.example.ui.theme.InstaPink
import com.example.ui.theme.StoryGradient
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: InstagramViewModel,
    modifier: Modifier = Modifier
) {
    val loggedInUser by viewModel.currentUser.collectAsState(null)
    val activeTab by viewModel.currentTab.collectAsState()
    val storyOverlayList by viewModel.viewingStoryGroup.collectAsState()
    val unreadNotifsCount by viewModel.unreadNotificationsCount.collectAsState()

    val isAdmin by viewModel.isAdminMode.collectAsState()

    // Adaptive sizes detection
    val config = LocalConfiguration.current
    val isTablet = config.screenWidthDp >= 600

    if (loggedInUser == null) {
        // Enforce Authentication
        AuthScreen(viewModel = viewModel)
        return
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            // Adaptive Navigation: Show sidebar navigation rail if on large tablet screens
            if (isTablet) {
                NavigationRail(
                    containerColor = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxHeight(),
                    header = {
                        Text(
                            text = "Socially",
                            fontFamily = FontFamily.Serif,
                            fontStyle = FontStyle.Italic,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            modifier = Modifier.padding(vertical = 24.dp),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                ) {
                    Spacer(modifier = Modifier.weight(1f))

                    NavigationRailItem(
                        selected = activeTab == "feed",
                        onClick = { viewModel.navigateToTab("feed") },
                        icon = { Icon(if (activeTab == "feed") Icons.Filled.Home else Icons.Outlined.Home, "Home Feed") },
                        label = { Text("Home", fontSize = 11.sp) }
                    )

                    NavigationRailItem(
                        selected = activeTab == "search",
                        onClick = { viewModel.navigateToTab("search") },
                        icon = { Icon(if (activeTab == "search") Icons.Filled.Explore else Icons.Outlined.Explore, "Search") },
                        label = { Text("Explore", fontSize = 11.sp) }
                    )

                    NavigationRailItem(
                        selected = activeTab == "reels",
                        onClick = { viewModel.navigateToTab("reels") },
                        icon = { Icon(if (activeTab == "reels") Icons.Filled.Movie else Icons.Outlined.Movie, "Reels") },
                        label = { Text("Reels", fontSize = 11.sp) }
                    )

                    NavigationRailItem(
                        selected = activeTab == "create",
                        onClick = { viewModel.navigateToTab("create") },
                        icon = { Icon(if (activeTab == "create") Icons.Filled.AddBox else Icons.Outlined.AddBox, "Publish") },
                        label = { Text("Create", fontSize = 11.sp) }
                    )

                    NavigationRailItem(
                        selected = activeTab == "notifications",
                        onClick = { viewModel.navigateToTab("notifications") },
                        icon = {
                            BadgedBox(badge = {
                                if (unreadNotifsCount > 0) {
                                    Badge { Text("$unreadNotifsCount") }
                                }
                            }) {
                                Icon(if (activeTab == "notifications") Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Alerts")
                            }
                        },
                        label = { Text("Alerts", fontSize = 11.sp) }
                    )

                    NavigationRailItem(
                        selected = activeTab == "profile" || activeTab == "profile_details",
                        onClick = { viewModel.navigateToTab("profile") },
                        icon = {
                            AvatarImage(
                                picId = loggedInUser?.profilePicture ?: "grad_sky",
                                username = loggedInUser?.username ?: "me",
                                size = 28.dp
                            )
                        },
                        label = { Text("Profile", fontSize = 11.sp) }
                    )

                    if (isAdmin) {
                        NavigationRailItem(
                            selected = activeTab == "admin",
                            onClick = { viewModel.navigateToTab("admin") },
                            icon = { Icon(Icons.Filled.Shield, "Admin", tint = InstaPink) },
                            label = { Text("Moderator", fontSize = 11.sp) }
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))
                }

                VerticalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)
            }

            // Central Area Viewports
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                // Navigation components layout switcher
                Crossfade(targetState = activeTab, animationSpec = tween(250), label = "main_crossfade") { tab ->
                    when (tab) {
                        "feed" -> FeedScreen(viewModel = viewModel, modifier = Modifier.fillMaxSize())
                        "search" -> SearchScreen(viewModel = viewModel, modifier = Modifier.fillMaxSize())
                        "reels" -> ReelsScreen(viewModel = viewModel, modifier = Modifier.fillMaxSize())
                        "create" -> CreatePostScreen(viewModel = viewModel, modifier = Modifier.fillMaxSize())
                        "messages", "chat_detail" -> MessagesScreen(viewModel = viewModel, modifier = Modifier.fillMaxSize())
                        "notifications" -> NotificationsScreen(viewModel = viewModel, modifier = Modifier.fillMaxSize())
                        "profile" -> ProfileScreen(viewModel = viewModel, isViewingOther = false, modifier = Modifier.fillMaxSize())
                        "profile_details" -> ProfileScreen(viewModel = viewModel, isViewingOther = true, modifier = Modifier.fillMaxSize())
                        "admin" -> AdminScreen(viewModel = viewModel, modifier = Modifier.fillMaxSize())
                        else -> FeedScreen(viewModel = viewModel, modifier = Modifier.fillMaxSize())
                    }
                }

                // Bottom Navigation controls: displayed strictly on compact portrait phones
                if (!isTablet) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f),
                            tonalElevation = 8.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(72.dp)
                                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp, bottomStart = 24.dp, bottomEnd = 24.dp))
                                .testTag("bottom_nav_container")
                        ) {
                            val activeColors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.secondaryContainer,
                                selectedIconColor = MaterialTheme.colorScheme.onSecondaryContainer,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            NavigationBarItem(
                                selected = activeTab == "feed",
                                onClick = { viewModel.navigateToTab("feed") },
                                icon = { Icon(if (activeTab == "feed") Icons.Filled.Home else Icons.Outlined.Home, null) },
                                colors = activeColors
                            )

                            NavigationBarItem(
                                selected = activeTab == "search",
                                onClick = { viewModel.navigateToTab("search") },
                                icon = { Icon(if (activeTab == "search") Icons.Filled.Explore else Icons.Outlined.Explore, null) },
                                colors = activeColors
                            )

                            NavigationBarItem(
                                selected = activeTab == "reels",
                                onClick = { viewModel.navigateToTab("reels") },
                                icon = { Icon(if (activeTab == "reels") Icons.Filled.Movie else Icons.Outlined.Movie, null) },
                                colors = activeColors
                            )

                            NavigationBarItem(
                                selected = activeTab == "create",
                                onClick = { viewModel.navigateToTab("create") },
                                icon = { Icon(if (activeTab == "create") Icons.Filled.AddBox else Icons.Outlined.AddBox, null) },
                                colors = activeColors
                            )

                            NavigationBarItem(
                                selected = activeTab == "notifications",
                                onClick = { viewModel.navigateToTab("notifications") },
                                icon = {
                                    BadgedBox(badge = {
                                        if (unreadNotifsCount > 0) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .clip(CircleShape)
                                                    .background(MaterialTheme.colorScheme.error)
                                            )
                                        }
                                    }) {
                                        Icon(if (activeTab == "notifications") Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, null)
                                    }
                                },
                                colors = activeColors
                            )

                            NavigationBarItem(
                                selected = activeTab == "profile",
                                onClick = { viewModel.navigateToTab("profile") },
                                icon = {
                                    val isSelected = activeTab == "profile" || activeTab == "profile_details"
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isSelected) Brush.sweepGradient(StoryGradient)
                                                else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                                            )
                                            .padding(if (isSelected) 2.dp else 0.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.surface)
                                            .padding(1.dp)
                                    ) {
                                        AvatarImage(
                                            picId = loggedInUser?.profilePicture ?: "grad_sky",
                                            username = loggedInUser?.username ?: "me",
                                            size = 24.dp
                                        )
                                    }
                                },
                                colors = activeColors
                            )

                            if (isAdmin) {
                                NavigationBarItem(
                                    selected = activeTab == "admin",
                                    onClick = { viewModel.navigateToTab("admin") },
                                    icon = { Icon(Icons.Filled.Shield, null) },
                                    colors = activeColors
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: Full-screen popup story viewer overlay layer
        if (storyOverlayList != null && storyOverlayList!!.isNotEmpty()) {
            val storyItem = storyOverlayList!!.first()
            FullScreenStoryOverlay(
                storyModel = storyItem,
                onDismiss = { viewModel.closeStories() }
            )
        }
    }
}

@Composable
fun FullScreenStoryOverlay(
    storyModel: StoryUiModel,
    onDismiss: () -> Unit
) {
    var storyProgress by remember { mutableStateOf(0f) }

    // Tick story progress bar for 4 seconds then auto close
    LaunchedEffect(Unit) {
        val duration = 4000
        val steps = 40
        val stepMs = (duration / steps).toLong()
        for (i in 1..steps) {
            delay(stepMs)
            storyProgress = i.toFloat() / steps.toFloat()
        }
        onDismiss()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("full_screen_story_overlay")
    ) {
        // High fidelity visual renderer
        ProceduralImageRenderer(
            mediaId = storyModel.story.mediaUrl,
            modifier = Modifier.fillMaxSize()
        )

        // Gradient dark shadow overlay for text readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent, Color.Black.copy(alpha = 0.7f))
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Upper: Progress tracker timer indicator + User Details
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Progress Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    LinearProgressIndicator(
                        progress = storyProgress,
                        color = InstaPink,
                        trackColor = Color.White.copy(alpha = 0.3f),
                        modifier = Modifier
                            .weight(1f)
                            .height(4.dp)
                            .clip(CircleShape)
                    )
                }

                // Meta Info Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AvatarImage(picId = storyModel.author.profilePicture, username = storyModel.author.username, size = 36.dp)
                        Column {
                            Text(text = storyModel.author.username, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = "2 hours ago", color = Color.LightGray, fontSize = 10.sp)
                        }
                    }

                    IconButton(onClick = { onDismiss() }) {
                        Icon(Icons.Default.Close, null, tint = Color.White)
                    }
                }
            }

            // Lower story caption text
            if (storyModel.story.caption.isNotEmpty()) {
                Text(
                    text = storyModel.story.caption,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 32.dp),
                    textAlign = TextAlign.Center
                )
            } else {
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}
