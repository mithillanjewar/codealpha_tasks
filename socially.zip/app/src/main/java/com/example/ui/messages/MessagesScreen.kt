package com.example.ui.messages

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MessageEntity
import com.example.ui.InstagramViewModel
import com.example.ui.components.AvatarImage
import com.example.ui.theme.InstaBlue
import com.example.ui.theme.InstaPink
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessagesScreen(
    viewModel: InstagramViewModel,
    modifier: Modifier = Modifier
) {
    val activeTab by viewModel.currentTab.collectAsState()
    val conversationsList by viewModel.conversationList.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState(emptyList())

    val activeChatId by viewModel.activeChatUserId.collectAsState()
    val activeChatMessages by viewModel.chatMessages.collectAsState(emptyList())
    val partnerTyping by viewModel.isChatPartnerTyping.collectAsState()

    val scope = rememberCoroutineScope()

    AnimatedContent(
        targetState = activeTab,
        transitionSpec = {
            if (activeTab == "chat_detail") {
                slideInHorizontally { width -> width } togetherWith slideOutHorizontally { width -> -width }
            } else {
                slideInHorizontally { width -> -width } togetherWith slideOutHorizontally { width -> width }
            }
        },
        label = "chat_screen_nav"
    ) { current ->
        if (current == "chat_detail" && activeChatId != null) {
            val otherUser = allUsers.find { it.id == activeChatId }
            ChatDetailScreen(
                otherUser = otherUser,
                messages = activeChatMessages,
                partnerTyping = partnerTyping,
                onBackClick = { viewModel.navigateToTab("messages") },
                onSendMsg = { text -> viewModel.sendDirectMessage(text) }
            )
        } else {
            // Main Conversations Page List
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(onClick = { viewModel.navigateToTab("feed") }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back to Feed")
                        }
                        Text(
                            text = "Messages",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.EditNote,
                        contentDescription = "New Message",
                        tint = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)

                if (conversationsList.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Chat,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No active conversations",
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Search users and share posts or say hi!",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 120.dp)
                    ) {
                        items(conversationsList) { convo ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.openChatWithUser(convo.otherUser.id) }
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                                    .testTag("conversation_row_${convo.otherUser.username}"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Profile icon + status indicator badge
                                Box {
                                    AvatarImage(
                                        picId = convo.otherUser.profilePicture,
                                        username = convo.otherUser.username,
                                        size = 54.dp
                                    )
                                    // Simulated Green Active dot indicators
                                    if (convo.otherUser.id != 4L) { // Limit alex & taylor is offline
                                        Box(
                                            modifier = Modifier
                                                .size(13.dp)
                                                .align(Alignment.BottomEnd)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.background)
                                                .padding(1.5.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF4CAF50))
                                        )
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = convo.otherUser.fullName,
                                        fontWeight = if (convo.unreadCount > 0) FontWeight.Bold else FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    Text(
                                        text = convo.lastMessage.message,
                                        fontSize = 13.sp,
                                        color = if (convo.unreadCount > 0) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        fontWeight = if (convo.unreadCount > 0) FontWeight.Bold else FontWeight.Normal
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (convo.unreadCount > 0) {
                                        Box(
                                            modifier = Modifier
                                                .size(20.dp)
                                                .clip(CircleShape)
                                                .background(InstaPink),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "${convo.unreadCount}",
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Icon(
                                        imageVector = Icons.Outlined.PhotoCamera,
                                        contentDescription = "Quick camera view",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    otherUser: com.example.data.UserEntity?,
    messages: List<MessageEntity>,
    partnerTyping: Boolean,
    onBackClick: () -> Unit,
    onSendMsg: (String) -> Unit
) {
    var txtMessageInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Auto scrolls to bottom on loaded DMs list
    LaunchedEffect(messages.size, partnerTyping) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AvatarImage(
                            picId = otherUser?.profilePicture ?: "grad_sky",
                            username = otherUser?.username ?: "anon",
                            size = 36.dp
                        )
                        Column {
                            Text(
                                text = otherUser?.fullName ?: "Chat",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (partnerTyping) "typing..." else "Active now",
                                fontSize = 11.sp,
                                color = if (partnerTyping) InstaPink else Color.Gray,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { onBackClick() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.LocalPhone, contentDescription = "Call")
                    }
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Videocam, contentDescription = "Video Call")
                    }
                }
            )
        },
        bottomBar = {
            // Typing response input controls bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .imePadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = txtMessageInput,
                    onValueChange = { txtMessageInput = it },
                    placeholder = { Text("Message...", fontSize = 14.sp) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    singleLine = true
                )

                if (txtMessageInput.trim().isNotEmpty()) {
                    Text(
                        text = "Send",
                        color = InstaBlue,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable {
                                onSendMsg(txtMessageInput.trim())
                                txtMessageInput = ""
                            }
                            .padding(8.dp)
                    )
                } else {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Mic, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Image, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg ->
                    val isMe = msg.senderId == 1L // Logged-in user Mithil
                    val align = if (isMe) Alignment.End else Alignment.Start
                    val bubbleColor = if (isMe) InstaBlue else MaterialTheme.colorScheme.surfaceVariant
                    val textColor = if (isMe) Color.White else MaterialTheme.colorScheme.onSurface

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = align
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(
                                    RoundedCornerShape(
                                        topStart = 16.dp,
                                        topEnd = 16.dp,
                                        bottomStart = if (isMe) 16.dp else 4.dp,
                                        bottomEnd = if (isMe) 4.dp else 16.dp
                                    )
                                )
                                .background(bubbleColor)
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                                .widthIn(max = 260.dp)
                        ) {
                            Text(
                                text = msg.message,
                                color = textColor,
                                fontSize = 14.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        // Subtext time stamp
                        Text(
                            text = "Just now",
                            fontSize = 9.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                    }
                }

                // Simulate Typing Loader Row
                if (partnerTyping) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(top = 8.dp)
                        ) {
                            AvatarImage(
                                picId = otherUser?.profilePicture ?: "grad_sky",
                                username = otherUser?.username ?: "anon",
                                size = 28.dp
                            )
                            TypingBubble()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TypingBubble() {
    // Elegant bouncing dot dots simulation inside chat bubble
    val infiniteTransition = rememberInfiniteTransition(label = "dots")
    val dotOffset1 by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = -6f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "dot1"
    )

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                Modifier
                    .size(6.dp)
                    .offset(y = dotOffset1.dp)
                    .clip(CircleShape)
                    .background(Color.Gray)
            )
            Box(
                Modifier
                    .size(6.dp)
                    .offset(y = (dotOffset1 * 0.7f).dp)
                    .clip(CircleShape)
                    .background(Color.Gray)
            )
            Box(
                Modifier
                    .size(6.dp)
                    .offset(y = (dotOffset1 * 0.4f).dp)
                    .clip(CircleShape)
                    .background(Color.Gray)
            )
        }
    }
}
