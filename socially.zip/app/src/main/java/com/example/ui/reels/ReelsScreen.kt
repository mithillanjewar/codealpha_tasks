package com.example.ui.reels

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CommentEntity
import com.example.data.UserEntity
import com.example.ui.InstagramViewModel
import com.example.ui.PostUiModel
import com.example.ui.components.AvatarImage
import com.example.ui.components.VideoPlayerRenderer
import com.example.ui.theme.InstaBlue
import com.example.ui.theme.InstaPink
import com.example.ui.theme.StoryGradient
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReelsScreen(
    viewModel: InstagramViewModel,
    modifier: Modifier = Modifier
) {
    val reelsList by viewModel.reels.collectAsState()
    val listState = rememberLazyListState()
    
    // Bottom overlay sheet state for comments
    var activeCommentingPostId by remember { mutableStateOf<Long?>(null) }
    
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("reels_screen_container")
    ) {
        if (reelsList.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.SlowMotionVideo,
                    contentDescription = null,
                    tint = Color.DarkGray,
                    modifier = Modifier.size(80.dp)
                )
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "No Video Reels Uploaded",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Go to the Create screen to share a video Konzept layout! Set trimmer to loop.",
                    color = Color.LightGray,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(reelsList) { _, postModel ->
                    ReelItemView(
                        postModel = postModel,
                        viewModel = viewModel,
                        onCommentClick = { activeCommentingPostId = postModel.post.id },
                        modifier = Modifier.fillParentMaxSize()
                    )
                }
            }
        }
        
        // Custom interactive comments sheet overlay
        AnimatedVisibility(
            visible = activeCommentingPostId != null,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            if (activeCommentingPostId != null) {
                ReelsCommentSheet(
                    postId = activeCommentingPostId!!,
                    viewModel = viewModel,
                    onDismiss = { activeCommentingPostId = null }
                )
            }
        }
    }
}

@Composable
fun ReelItemView(
    postModel: PostUiModel,
    viewModel: InstagramViewModel,
    onCommentClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var isDoubleTapHeartVisible by remember { mutableStateOf(false) }
    
    // Follow Status Simulation (using follow list on current view)
    val followingUsers by viewModel.myFollowing.collectAsState(emptyList())
    val isFollowingAuthor = followingUsers.any { it.id == postModel.author.id }
    val loggedInUser by viewModel.currentUser.collectAsState(null)
    val isMe = loggedInUser?.id == postModel.author.id
    
    Box(
        modifier = modifier
            .background(Color.Black)
            .testTag("reel_item_${postModel.post.id}")
    ) {
        // Immersive Background Player
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onDoubleTap = {
                            isDoubleTapHeartVisible = true
                            if (!postModel.isLiked) {
                                viewModel.toggleLikePost(postModel.post.id)
                            }
                        },
                        onTap = {
                            // Single tap pauses/plays handled by internal renderer,
                            // or simple mute toggle could occur here
                        }
                    )
                }
        ) {
            VideoPlayerRenderer(
                videoUrl = postModel.post.videoUrl,
                maxDurationMs = postModel.post.videoDurationMs,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Drifting radial dark shading overlay to secure text readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.4f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.75f)
                        )
                    )
                )
        )

        // Floating Double Tap Large Heart FX
        AnimatedVisibility(
            visible = isDoubleTapHeartVisible,
            enter = fadeIn(tween(150)) + scaleIn(initialScale = 0.5f, animationSpec = spring(dampingRatio = 0.5f)),
            exit = fadeOut(tween(250)) + scaleOut(targetScale = 1.5f),
            modifier = Modifier.align(Alignment.Center)
        ) {
            LaunchedEffect(isDoubleTapHeartVisible) {
                if (isDoubleTapHeartVisible) {
                    delay(700)
                    isDoubleTapHeartVisible = false
                }
            }
            Icon(
                imageVector = Icons.Filled.Favorite,
                contentDescription = "Liked",
                tint = InstaPink,
                modifier = Modifier.size(100.dp)
            )
        }

        // Creator Identity & Caption info (Bottom Left)
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth(0.78f)
                .padding(16.dp)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(bottom = 56.dp) // Leave clean spacing above navigation bar
        ) {
            // Account Details Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.clickable {
                    viewModel.focusOnUser(postModel.author.id)
                }
            ) {
                AvatarImage(
                    picId = postModel.author.profilePicture,
                    username = postModel.author.username,
                    size = 38.dp
                )
                
                Text(
                    text = "@${postModel.author.username}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                
                if (!isMe) {
                    Button(
                        onClick = {
                            // Standard follow trigger
                            viewModel.focusOnUser(postModel.author.id)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isFollowingAuthor) Color.White.copy(alpha = 0.15f) else InstaPink,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(24.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (isFollowingAuthor) "Following" else "Follow",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Expanded/Truncated Caption
            var isCaptionExpanded by remember { mutableStateOf(false) }
            Text(
                text = postModel.post.caption,
                color = Color.White,
                fontSize = 13.sp,
                maxLines = if (isCaptionExpanded) 6 else 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .clickable { isCaptionExpanded = !isCaptionExpanded }
                    .animateContentSize()
            )
            
            Spacer(modifier = Modifier.height(10.dp))
            
            // Music track Concept
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = "Audio track",
                    tint = Color.LightGray,
                    modifier = Modifier.size(14.dp)
                )
                
                // Animated sound equalizer simulation
                val wavePulse = rememberInfiniteTransition(label = "audio_ripple")
                val audioAlpha by wavePulse.animateFloat(
                    initialValue = 0.5f,
                    targetValue = 1.0f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(800, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "alpha"
                )
                
                Text(
                    text = "Original Audio - @${postModel.author.username}",
                    color = Color.LightGray.copy(alpha = audioAlpha),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    overflow = TextOverflow.Ellipsis,
                    maxLines = 1
                )
            }
        }

        // Interaction HUD Control Palette (Bottom Right)
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 12.dp, bottom = 80.dp)
                .windowInsetsPadding(WindowInsets.navigationBars),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Like button Action
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable { viewModel.toggleLikePost(postModel.post.id) }
            ) {
                Icon(
                    imageVector = if (postModel.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Like Reel",
                    tint = if (postModel.isLiked) InstaPink else Color.White,
                    modifier = Modifier
                        .size(28.dp)
                        .scale(if (postModel.isLiked) 1.15f else 1f)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${postModel.likesCount}",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // 2. Comments panel launcher
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable { onCommentClick() }
            ) {
                Icon(
                    imageVector = Icons.Outlined.ChatBubbleOutline,
                    contentDescription = "Comments",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${postModel.commentsCount}",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // 3. Share icon
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable {
                    // Simulates linking/sharing
                }
            ) {
                Icon(
                    imageVector = Icons.Outlined.Share,
                    contentDescription = "Share",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Share",
                    color = Color.LightGray,
                    fontSize = 10.sp
                )
            }

            // 4. Music Vinyl Disc rotating icon FX
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.DarkGray)
                    .padding(4.dp)
                    .clip(CircleShape)
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                val infiniteRotation = rememberInfiniteTransition(label = "vinyl_disc")
                val angle by infiniteRotation.animateFloat(
                    initialValue = 0f,
                    targetValue = 360f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(4000, easing = LinearEasing)
                    ),
                    label = "rotation"
                )
                
                Icon(
                    imageVector = Icons.Default.Album,
                    contentDescription = "Music spinning",
                    tint = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier
                        .size(24.dp)
                        .scale(1.1f)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReelsCommentSheet(
    postId: Long,
    viewModel: InstagramViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val comments by viewModel.repository.commentDao.getCommentsByPostIdFlow(postId).collectAsState(emptyList())
    val users by viewModel.allUsers.collectAsState(emptyList())
    var commentText by remember { mutableStateOf("") }
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.6f)
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .background(Color(0xFF161618))
            .testTag("reels_comments_panel")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 8.dp)
        ) {
            // Drag handle and header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 40.dp, height = 4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color.Gray.copy(alpha = 0.5f))
                )
            }
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Comments (${comments.size})",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close panel",
                        tint = Color.White
                    )
                }
            }
            
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

            // Comments lists
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (comments.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ChatBubbleOutline,
                            contentDescription = null,
                            tint = Color.DarkGray,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No comments yet",
                            color = Color.LightGray,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Start the conversation!",
                            color = Color.DarkGray,
                            fontSize = 11.sp
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(comments.size) { index ->
                            val comment = comments[index]
                            val author = users.find { it.id == comment.userId } ?: UserEntity(
                                username = "anonymous",
                                fullName = "Anonymous",
                                email = "",
                                passwordHash = "",
                                profilePicture = "grad_sky",
                                bio = "",
                                website = ""
                            )
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                AvatarImage(
                                    picId = author.profilePicture,
                                    username = author.username,
                                    size = 32.dp
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = author.username,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = "just now", // Simulated relative time
                                            color = Color.DarkGray,
                                            fontSize = 10.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = comment.commentText,
                                        color = Color.LightGray,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

            // Text input docking station
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.ime)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = commentText,
                    onValueChange = { commentText = it },
                    placeholder = { Text("Add a comment...", fontSize = 13.sp, color = Color.Gray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Black.copy(alpha = 0.3f),
                        unfocusedContainerColor = Color.Black.copy(alpha = 0.3f),
                        focusedBorderColor = InstaPink.copy(alpha = 0.8f),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.1f)
                    ),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    textStyle = TextStyle(fontSize = 13.sp, color = Color.White)
                )
                
                Button(
                    onClick = {
                        if (commentText.trim().isNotEmpty()) {
                            viewModel.addComment(postId, commentText)
                            commentText = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = InstaPink),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Text("Post", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}
