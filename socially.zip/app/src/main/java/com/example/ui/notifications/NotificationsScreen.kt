package com.example.ui.notifications

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NotificationEntity
import com.example.ui.InstagramViewModel
import com.example.ui.NotificationUiModel
import com.example.ui.components.AvatarImage
import com.example.ui.theme.InstaBlue
import com.example.ui.theme.InstaPink

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    viewModel: InstagramViewModel,
    modifier: Modifier = Modifier
) {
    val notificationList by viewModel.notifications.collectAsState()
    val pendingRequests by viewModel.pendingFollowRequests.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("notifications_screen_layout")
    ) {
        // Optional high contrast push notifications toggle state
        var isPushEnabled by remember { mutableStateOf(false) }

        // Toolbar header bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Notifications",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Text(
                        text = if (isPushEnabled) "Push Notifications: ACTIVE" else "Push Notifications: OFF",
                        fontSize = 11.sp,
                        color = if (isPushEnabled) InstaPink else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                    Switch(
                        checked = isPushEnabled,
                        onCheckedChange = { isPushEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = InstaPink,
                            uncheckedThumbColor = MaterialTheme.colorScheme.outline,
                            uncheckedTrackColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier
                            .scale(0.7f)
                            .height(18.dp)
                    )
                }
            }

            if (notificationList.isNotEmpty()) {
                IconButton(onClick = { viewModel.clearNotifications() }) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteSweep,
                        contentDescription = "Mark all as read",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Section 1: Private Account Follow requests
            if (pendingRequests.isNotEmpty()) {
                item {
                    Text(
                        text = "Follow Requests",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = InstaPink,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                items(pendingRequests) { requester ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            AvatarImage(picId = requester.profilePicture, username = requester.username, size = 44.dp)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = requester.username,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "wants to follow you.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                IconButton(
                                    onClick = { viewModel.acceptFollowRequest(requester.id) },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(InstaBlue)
                                ) {
                                    Icon(Icons.Outlined.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = { viewModel.declineFollowRequest(requester.id) },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Icon(Icons.Outlined.Close, null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                item {
                    Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 8.dp))
                }
            }

            // Section 2: General Notifications logs
            if (notificationList.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(64.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No new notifications",
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Activity on your posts, likes, DMs, and story vibes will show up here!",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            } else {
                items(notificationList) { notifyModel ->
                    NotificationRowItem(
                        model = notifyModel,
                        onClick = { viewModel.focusOnUser(notifyModel.sender.id) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(120.dp))
            }
        }
    }
}

@Composable
fun NotificationRowItem(
    model: NotificationUiModel,
    onClick: () -> Unit
) {
    val notif = model.notification
    val textSegment = when (notif.type) {
        "LIKE" -> "liked your post."
        "COMMENT" -> "commented on your post."
        "FOLLOW" -> "started following you."
        "FOLLOW_REQUEST" -> "requested to follow you."
        "MESSAGE" -> "sent you a direct message."
        "MENTION" -> "mentioned you in a post or comment!"
        else -> "interacted with you."
    }

    val iconSource = when (notif.type) {
        "LIKE" -> Icons.Outlined.Notifications
        "COMMENT" -> Icons.Outlined.Notifications
        else -> Icons.Outlined.Notifications
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AvatarImage(picId = model.sender.profilePicture, username = model.sender.username, size = 48.dp)

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = model.sender.username,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                if (!notif.isRead) {
                    Box(
                        modifier = Modifier
                            .padding(start = 6.dp)
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(InstaPink)
                    )
                }
            }
            Text(
                text = textSegment,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            // Time stamp
            Text(
                text = "just now",
                fontSize = 10.sp,
                color = Color.Gray,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}
