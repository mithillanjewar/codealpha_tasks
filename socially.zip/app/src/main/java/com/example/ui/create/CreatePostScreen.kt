package com.example.ui.create

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.InstagramViewModel
import com.example.ui.components.ProceduralImageRenderer
import com.example.ui.components.VideoPlayerRenderer
import com.example.ui.theme.InstaBlue
import com.example.ui.theme.InstaPink
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePostScreen(
    viewModel: InstagramViewModel,
    modifier: Modifier = Modifier
) {
    var caption by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var hashtags by remember { mutableStateOf("") }

    // Preset available image templates matching our procedural drawer
    val visualTemplates = listOf(
        "unsplash_travel" to "Nature/Adventure",
        "unsplash_bake" to "Baking & Pastries",
        "unsplash_studio" to "Studio / Synthesizers",
        "unsplash_code" to "Tech Terminal Code"
    )

    // Preset video templates for short reels
    val videoTemplates = listOf(
        "unsplash_studio_1" to "Production Studio Stream",
        "unsplash_travel_1" to "Kyoto Sunset Drone",
        "unsplash_bake_1" to "Fresh Sourdough Loop"
    )
    
    val videoUrls = listOf(
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
    )

    // Current selected image
    var selectedTemplate by remember { mutableStateOf(visualTemplates[0].first) }
    var selectedVideoIndex by remember { mutableStateOf(0) }

    var isVideoPost by remember { mutableStateOf(false) }

    // Carousel simulation (Can pick multiple image strings)
    var isCarouselMode by remember { mutableStateOf(false) }
    val selectedCarouselTemplates = remember { mutableStateListOf("unsplash_travel") }

    // Trim sliders
    var trimStartSeconds by remember { mutableStateOf(0f) }
    var trimEndSeconds by remember { mutableStateOf(15f) }
    var selectedResolutionOption by remember { mutableStateOf("1080p (Original)") }

    // Live transcoding simulated dialogue overlay
    var showTranscodeProgressDialog by remember { mutableStateOf(false) }
    var transcodeProgressFraction by remember { mutableStateOf(0f) }
    var transcodeStepText by remember { mutableStateOf("") }

    // Toggle to additionally post to active stories
    var alsoPostToStory by remember { mutableStateOf(false) }

    // Transcoder background process simulator
    LaunchedEffect(showTranscodeProgressDialog) {
        if (showTranscodeProgressDialog) {
            val steps = listOf(
                "Initializing offline FFmpeg transcoding codecs...",
                "Trimming video clip from ${String.format("%.1f", trimStartSeconds)}s to ${String.format("%.1f", trimEndSeconds)}s...",
                "Encoding audio AAC structures & syncing video keyframes...",
                "Resolving optimized bitrate blocks for $selectedResolutionOption...",
                "Transcoding finalized MP4 container stream...",
                "Uploading transcoded buffers to Picstagram node..."
            )
            transcodeProgressFraction = 0f
            for (i in steps.indices) {
                transcodeStepText = steps[i]
                delay(750)
                transcodeProgressFraction = (i + 1).toLong() / steps.size.toFloat()
            }
            showTranscodeProgressDialog = false
            
            // Publish the post!
            val mediaList = if (isVideoPost) {
                listOf(videoTemplates[selectedVideoIndex].first)
            } else if (isCarouselMode) {
                selectedCarouselTemplates.toList()
            } else {
                listOf(selectedTemplate)
            }
            viewModel.createPost(
                imageUrls = mediaList,
                caption = caption.trim(),
                location = location.trim(),
                hashtags = hashtags.trim(),
                isVideo = isVideoPost,
                videoUrl = if (isVideoPost) videoUrls[selectedVideoIndex] else "",
                transcodeResolution = if (isVideoPost) selectedResolutionOption else "1080p (Original)",
                videoDurationMs = if (isVideoPost) ((trimEndSeconds - trimStartSeconds) * 1000).toLong() else 0L
            )

            // Additionally publish story
            if (alsoPostToStory) {
                viewModel.createStory(
                    mediaUrl = mediaList.first(),
                    caption = if (caption.length > 30) caption.take(30) + "..." else caption
                )
            }

            // Reset forms
            caption = ""
            location = ""
            hashtags = ""
            trimStartSeconds = 0f
            trimEndSeconds = 15f
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Create New Post",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Start
        )

        // Type Selectors tab-row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Button(
                onClick = { isVideoPost = false; isCarouselMode = false },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (!isVideoPost) MaterialTheme.colorScheme.primary else Color.Transparent,
                    contentColor = if (!isVideoPost) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Photo, null, modifier = Modifier.size(16.dp))
                    Text("Standard Images", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Button(
                onClick = { isVideoPost = true },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isVideoPost) InstaPink else Color.Transparent,
                    contentColor = if (isVideoPost) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Videocam, null, modifier = Modifier.size(16.dp))
                    Text("Short Video Reel", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Selected Media Preview container
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .testTag("preview_post_card"),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (isVideoPost) {
                    // Responsive live video player preview inside the draft creation!
                    VideoPlayerRenderer(
                        videoUrl = videoUrls[selectedVideoIndex],
                        modifier = Modifier.fillMaxSize(),
                        maxDurationMs = ((trimEndSeconds - trimStartSeconds) * 1000).toLong()
                    )
                } else {
                    ProceduralImageRenderer(
                        mediaId = if (isCarouselMode) selectedCarouselTemplates.last() else selectedTemplate,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Carousel indicator overlay
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isVideoPost) "Video Reel Mode" else if (isCarouselMode) "Carousel Mode: ${selectedCarouselTemplates.size} pics" else "Single Photo Mode",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Section: Pick visual themes
        Text(
            text = if (isVideoPost) "Select Video Loop Concept:" else "Choose Visual Theme Concept:",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (isVideoPost) {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(videoTemplates.size) { idx ->
                    val (id, label) = videoTemplates[idx]
                    val isSelected = selectedVideoIndex == idx
                    val cardColor = if (isSelected) InstaPink.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                    val strokeColor = if (isSelected) InstaPink else Color.Transparent

                    Card(
                        modifier = Modifier
                            .width(160.dp)
                            .border(1.5.dp, strokeColor, RoundedCornerShape(12.dp))
                            .clickable { selectedVideoIndex = idx },
                        colors = CardDefaults.cardColors(containerColor = cardColor)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = if (isSelected) InstaPink else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center,
                                color = if (isSelected) InstaPink else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // High-fidelity Trimming/Editing controls
            Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)
            Text(
                text = "Video Editing & Trimming Console:",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Start Limit: ${String.format("%.1f", trimStartSeconds)}s", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Playback Window: ${String.format("%.1f", trimEndSeconds - trimStartSeconds)}s total", fontSize = 12.sp, color = InstaPink, fontWeight = FontWeight.Black)
                        Text("End Limit: ${String.format("%.1f", trimEndSeconds)}s", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Column {
                        Text("Set Clip Start Timestamp:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Slider(
                            value = trimStartSeconds,
                            onValueChange = {
                                if (it < trimEndSeconds - 2f) {
                                    trimStartSeconds = it
                                }
                            },
                            valueRange = 0f..15f,
                            colors = SliderDefaults.colors(thumbColor = InstaPink, activeTrackColor = InstaPink)
                        )
                    }

                    Column {
                        Text("Set Clip End Timestamp (Duration):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Slider(
                            value = trimEndSeconds,
                            onValueChange = {
                                if (it > trimStartSeconds + 2f) {
                                    trimEndSeconds = it
                                }
                            },
                            valueRange = 5f..30f,
                            colors = SliderDefaults.colors(thumbColor = InstaPink, activeTrackColor = InstaPink)
                        )
                    }
                }
            }

            // Resolution selection cards
            Text(
                text = "Upload transcode bitrates & format resolution:",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("1080p (HQ Original)", "720p (HD Web)", "480p (Mobile Compact)").forEach { opt ->
                    val isSelected = selectedResolutionOption == opt
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) InstaPink else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { selectedResolutionOption = opt }
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = opt.substringBefore(" "),
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

        } else {
            // Standard photo grid theme selector
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val themeCount = visualTemplates.size
                items(themeCount) { idx ->
                    val (id, label) = visualTemplates[idx]
                    val isSelected = if (isCarouselMode) selectedCarouselTemplates.contains(id) else selectedTemplate == id
                    val cardColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant

                    Card(
                        modifier = Modifier
                            .width(135.dp)
                            .clickable {
                                if (isCarouselMode) {
                                    if (selectedCarouselTemplates.contains(id)) {
                                        if (selectedCarouselTemplates.size > 1) {
                                            selectedCarouselTemplates.remove(id)
                                        }
                                    } else {
                                        selectedCarouselTemplates.add(id)
                                    }
                                } else {
                                    selectedTemplate = id
                                }
                            },
                        colors = CardDefaults.cardColors(containerColor = cardColor)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddAPhoto,
                                contentDescription = null,
                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Multiple Images (Carousel Post)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Switch(
                    checked = isCarouselMode,
                    onCheckedChange = { isCarouselMode = it }
                )
            }
        }

        Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)

        // Metadata inputs: Caption, location, tags
        OutlinedTextField(
            value = caption,
            onValueChange = { caption = it },
            label = { Text("Write a caption...") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("caption_input_field"),
            shape = RoundedCornerShape(12.dp),
            maxLines = 4
        )

        OutlinedTextField(
            value = location,
            onValueChange = { location = it },
            label = { Text("Add Location") },
            leadingIcon = { Icon(Icons.Default.LocationOn, null) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = hashtags,
            onValueChange = { hashtags = it },
            label = { Text("Tags & Hashtags (comma separated)") },
            leadingIcon = { Icon(Icons.Default.Sell, null) },
            placeholder = { Text("android, travel, sourdough") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        // Toggle additionally share to story
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = alsoPostToStory,
                onCheckedChange = { alsoPostToStory = it }
            )
            Text(
                text = "Also share this as active 24-hr Story",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Action submit button
        Button(
            onClick = {
                if (isVideoPost) {
                    showTranscodeProgressDialog = true
                } else {
                    val mediaList = if (isCarouselMode) {
                        selectedCarouselTemplates.toList()
                    } else {
                        listOf(selectedTemplate)
                    }
                    viewModel.createPost(
                        imageUrls = mediaList,
                        caption = caption.trim(),
                        location = location.trim(),
                        hashtags = hashtags.trim(),
                        isVideo = false
                    )

                    // Additionally publish story
                    if (alsoPostToStory) {
                        viewModel.createStory(
                            mediaUrl = mediaList.first(),
                            caption = if (caption.length > 30) caption.take(30) + "..." else caption
                        )
                    }

                    // Reset forms
                    caption = ""
                    location = ""
                    hashtags = ""
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("publish_post_button"),
            colors = ButtonDefaults.buttonColors(containerColor = if (isVideoPost) InstaPink else MaterialTheme.colorScheme.primary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = if (isVideoPost) "Trimming & Transcode Video Reel" else "Share Post",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(120.dp))
    }

    // Modal Progress Dialog matching requirements
    if (showTranscodeProgressDialog) {
        AlertDialog(
            onDismissRequest = {},
            title = {
                Text(
                    text = "FFmpeg Transcoding Core",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = InstaPink
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(
                        progress = transcodeProgressFraction,
                        color = InstaPink,
                        strokeWidth = 6.dp,
                        modifier = Modifier.size(72.dp)
                    )
                    
                    Text(
                        text = "${(transcodeProgressFraction * 100).toInt()}% Done",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp
                    )
                    
                    Text(
                        text = transcodeStepText,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {}
        )
    }
}
