package com.example.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Repository(private val database: AppDatabase) {
    val userDao = database.userDao()
    val postDao = database.postDao()
    val commentDao = database.commentDao()
    val likeDao = database.likeDao()
    val followerDao = database.followerDao()
    val storyDao = database.storyDao()
    val messageDao = database.messageDao()
    val notificationDao = database.notificationDao()

    private val _currentUserId = MutableStateFlow<Long?>(null)
    val currentUserId: StateFlow<Long?> = _currentUserId.asStateFlow()

    val currentUser: Flow<UserEntity?> = currentUserId.flatMapLatest { id ->
        if (id == null) flowOf(null)
        else userDao.getUserByIdFlow(id)
    }

    init {
        // Prepopulate with seed data on secondary thread if empty
        CoroutineScope(Dispatchers.IO).launch {
            if (userDao.getUserByUsername("mithil") == null) {
                prepopulateDatabase()
            } else {
                // Default logged in user to the main user
                val me = userDao.getUserByUsername("mithil")
                if (me != null) {
                    _currentUserId.value = me.id
                }
            }
        }
    }

    suspend fun login(username: String, passwordHash: String): Boolean = withContext(Dispatchers.IO) {
        val user = userDao.getUserByUsername(username)
        if (user != null && user.passwordHash == passwordHash) {
            _currentUserId.value = user.id
            return@withContext true
        }
        return@withContext false
    }

    suspend fun register(
        username: String,
        fullName: String,
        email: String,
        passwordHash: String,
        bio: String,
        website: String,
        profilePic: String
    ): Boolean = withContext(Dispatchers.IO) {
        val existingUser = userDao.getUserByUsername(username)
        if (existingUser != null) return@withContext false

        val newUser = UserEntity(
            username = username,
            fullName = fullName,
            email = email,
            passwordHash = passwordHash,
            bio = bio,
            website = website,
            profilePicture = profilePic,
            isPrivate = false
        )
        val newId = userDao.insertUser(newUser)
        _currentUserId.value = newId
        return@withContext true
    }

    fun logout() {
        _currentUserId.value = null
    }

    suspend fun updateProfile(user: UserEntity) = withContext(Dispatchers.IO) {
        userDao.updateUser(user)
    }

    // Prepopulate seed data
    private suspend fun prepopulateDatabase() {
        // 1. Core Users
        val meId = userDao.insertUser(
            UserEntity(
                username = "mithil",
                fullName = "Mithil Lanjewar",
                email = "mithillanjewar@gmail.com",
                passwordHash = "password",
                profilePicture = "grad_sky",
                bio = "Exploring Android, jetpack compose, and building cool things. Let's connect!",
                website = "github.com/mithil",
                isPrivate = false
            )
        )
        _currentUserId.value = meId

        val jessId = userDao.insertUser(
            UserEntity(
                username = "jess_travels",
                fullName = "Jessica Miller",
                email = "jess@example.com",
                passwordHash = "password",
                profilePicture = "grad_orange",
                bio = "Wanderlust ✈️ | Travel photographer. Seeking moments, not things.",
                website = "jessicaphotography.com",
                isPrivate = false
            )
        )

        val alexId = userDao.insertUser(
            UserEntity(
                username = "alex_bakes",
                fullName = "Alex Rivera",
                email = "alex@example.com",
                passwordHash = "password",
                profilePicture = "grad_pink",
                bio = "Pastry chef 🥐 Sourdough whisperer. Baking happiness daily.",
                website = "alexbakes.net",
                isPrivate = false
            )
        )

        val jordanId = userDao.insertUser(
            UserEntity(
                username = "jordan_fits",
                fullName = "Jordan Parker",
                email = "jordan@example.com",
                passwordHash = "password",
                profilePicture = "grad_teal",
                bio = "Health Coach 💪 | Yoga & HIIT teacher. Mind over matter. Stay hydrated!",
                website = "jordanfits.com",
                isPrivate = true // Private account to demonstrate follow requests
            )
        )

        val taylorId = userDao.insertUser(
            UserEntity(
                username = "taylor_tunes",
                fullName = "Taylor Vance",
                email = "taylor@example.com",
                passwordHash = "password",
                profilePicture = "grad_purple",
                bio = "Guitarist & Producer 🎸 | Sonic experiments and tape delay enthusiasts.",
                website = "taylorvancemusic.com",
                isPrivate = false
            )
        )

        // 2. Stories
        val now = System.currentTimeMillis()
        storyDao.insertStory(StoryEntity(userId = jessId, mediaUrl = "unsplash_travel", caption = "Morning view in Tokyo!", expiresAt = now + 86400000))
        storyDao.insertStory(StoryEntity(userId = alexId, mediaUrl = "unsplash_bake", caption = "Fresh croissants are out!", expiresAt = now + 86400000))
        storyDao.insertStory(StoryEntity(userId = taylorId, mediaUrl = "unsplash_studio", caption = "Tracking acoustic guitars today", expiresAt = now + 86400000))
        storyDao.insertStory(StoryEntity(userId = meId, mediaUrl = "unsplash_android", caption = "Building Picstagram and compiling seamlessly!", expiresAt = now + 86400000))

        // 3. Follow connections (Mutual follows)
        followerDao.insertFollow(FollowerEntity(followerId = meId, followingId = jessId, isPending = false))
        followerDao.insertFollow(FollowerEntity(followerId = jessId, followingId = meId, isPending = false))
        followerDao.insertFollow(FollowerEntity(followerId = meId, followingId = alexId, isPending = false))
        followerDao.insertFollow(FollowerEntity(followerId = alexId, followingId = meId, isPending = false))
        followerDao.insertFollow(FollowerEntity(followerId = meId, followingId = taylorId, isPending = false))

        // Let's create a pending request to Jordan's private account
        followerDao.insertFollow(FollowerEntity(followerId = meId, followingId = jordanId, isPending = true))

        // Someone requesting to follow ME ( Mithil )
        val gamerId = userDao.insertUser(
            UserEntity(
                username = "retro_gamer",
                fullName = "Leo Watts",
                email = "leo@example.com",
                passwordHash = "password",
                profilePicture = "grad_lime",
                bio = "CRT monitor advocate. Collects retro cartridges.",
                website = "retrowatts.dev",
                isPrivate = false
            )
        )
        // Request from retro_gamer is pending
        followerDao.insertFollow(FollowerEntity(followerId = gamerId, followingId = meId, isPending = true))

        // 4. Posts
        val postVideoId = postDao.insertPost(
            PostEntity(
                userId = taylorId,
                imageUrls = "unsplash_studio_1",
                caption = "Warm analog tubes heating up the studio. High-fidelity acoustic guitar tracking in real-time loop! 🎸🎙️ #audiophile #studiolife #producersworld",
                location = "Valves & Tape Studio",
                hashtags = "audiophile,studiolife,producersworld",
                isVideo = true,
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                transcodeResolution = "1080p (Original)",
                videoDurationMs = 15000
            )
        )

        val post1Id = postDao.insertPost(
            PostEntity(
                userId = jessId,
                imageUrls = "unsplash_travel_1,unsplash_travel_2", // Carousel post (two image strings)
                caption = "Strolling through the hidden alleys of Kyoto. So peaceful here. 🇯🇵🏮 #kyoto #japan #travelblog #adventure",
                location = "Kyoto, Japan",
                hashtags = "kyoto,japan,travelblog,adventure"
            )
        )

        val postVideoTravelId = postDao.insertPost(
            PostEntity(
                userId = jessId,
                imageUrls = "unsplash_travel",
                caption = "Scenic drone capture flying high above Kyoto bamboo grove streams. Absolute paradise! ⛩️✈️ #kyoto #japan #travelblog #adventure",
                location = "Kyoto, Japan",
                hashtags = "kyoto,japan,travelblog,adventure",
                isVideo = true,
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                transcodeResolution = "720p (Transcoded)",
                videoDurationMs = 30000
            )
        )

        val post2Id = postDao.insertPost(
            PostEntity(
                userId = alexId,
                imageUrls = "unsplash_bake_1",
                caption = "Look at that crumb structure! Sourdough baking is a therapeutic science. 🥖🍞 Wheat flour, water, salt, and direct wild starter focus. #sourdough #baking #artisanbread #foodie",
                location = "Wild Crumb Bakery",
                hashtags = "sourdough,baking,artisanbread,foodie"
            )
        )

        val post3Id = postDao.insertPost(
            PostEntity(
                userId = taylorId,
                imageUrls = "unsplash_studio_1",
                caption = "Warm analog tubes heating up the studio. Preparing the next record. Pure signal chains and warm preamps. 🎙️🎚️ #audiophile #studiolife #producersworld",
                location = "Valves & Tape Studio",
                hashtags = "audiophile,studiolife,producersworld"
            )
        )

        val post4Id = postDao.insertPost(
            PostEntity(
                userId = meId,
                imageUrls = "unsplash_code_1",
                caption = "Double tap if you love programming in Jetpack Compose! Building elegant Android Apps in real-time. Responsive design and Material 3 is beautiful! 🚀📱💻 #jetpackcompose #androiddev #materialdesign",
                location = "Google AI Studio",
                hashtags = "jetpackcompose,androiddev,materialdesign"
            )
        )

        // 5. Likes and Comments
        likeDao.insertLike(LikeEntity(userId = jessId, postId = post4Id))
        likeDao.insertLike(LikeEntity(userId = alexId, postId = post4Id))
        likeDao.insertLike(LikeEntity(userId = taylorId, postId = post4Id))
        likeDao.insertLike(LikeEntity(userId = meId, postId = post1Id))
        likeDao.insertLike(LikeEntity(userId = alexId, postId = post1Id))

        commentDao.insertComment(CommentEntity(postId = post4Id, userId = jessId, commentText = "This looks absolutely clean! Excellent padding and custom layout spacing."))
        commentDao.insertComment(CommentEntity(postId = post4Id, userId = alexId, commentText = "Jetpack Compose is indeed amazing, simplifies layout nesting!"))
        commentDao.insertComment(CommentEntity(postId = post1Id, userId = meId, commentText = "Amazing photo Jessica, Kyoto is on my bucket list!"))

        // Add a nested reply nested under Comment 1
        commentDao.insertComment(CommentEntity(postId = post4Id, userId = meId, commentText = "Thanks Jessica! Making sure to follow all dynamic Material 3 tokens.", parentCommentId = 1L))

        // 6. Direct Messages (Chats)
        messageDao.insertMessage(MessageEntity(senderId = jessId, receiverId = meId, message = "Hey Mithil! Loved your latest post on Jetpack Compose!"))
        messageDao.insertMessage(MessageEntity(senderId = meId, receiverId = jessId, message = "Hi Jess! Thanks so much! Your Kyoto travel logs are looking gorgeous as well."))
        messageDao.insertMessage(MessageEntity(senderId = jessId, receiverId = meId, message = "Thanks! Are you planning to visit Japan soon? I have some cool recommendations for coffee spots! ☕️"))

        // Add message conversation from Alex
        messageDao.insertMessage(MessageEntity(senderId = alexId, receiverId = meId, message = "Mithil, I need to show you the sourdough bread I baked today! Let me know when you are free to try some."))

        // 7. Notifications
        notificationDao.insertNotification(NotificationEntity(userId = meId, senderId = jessId, type = "LIKE", referenceId = post4Id, isRead = false))
        notificationDao.insertNotification(NotificationEntity(userId = meId, senderId = alexId, type = "LIKE", referenceId = post4Id, isRead = false))
        notificationDao.insertNotification(NotificationEntity(userId = meId, senderId = jessId, type = "COMMENT", referenceId = post4Id, isRead = false))
        notificationDao.insertNotification(NotificationEntity(userId = meId, senderId = gamerId, type = "FOLLOW_REQUEST", referenceId = gamerId, isRead = false))
    }
}
