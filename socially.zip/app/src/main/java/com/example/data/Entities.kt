package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val fullName: String,
    val email: String,
    val passwordHash: String,
    val profilePicture: String, // String representation (resource ID string or local drawable placeholder or web URL)
    val bio: String,
    val website: String,
    val isPrivate: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val imageUrls: String, // Comma-separated list for card carousels
    val caption: String,
    val location: String = "",
    val hashtags: String = "", // Comma-separated hashtags
    val isVideo: Boolean = false,
    val videoUrl: String = "",
    val transcodeResolution: String = "1080p (Original)",
    val videoDurationMs: Long = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "comments")
data class CommentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val postId: Long,
    val userId: Long,
    val commentText: String,
    val parentCommentId: Long? = null, // Nullable for support of nested comments
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "likes")
data class LikeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val postId: Long,
    val commentId: Long? = null, // Support for comment likes or post likes
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "followers")
data class FollowerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val followerId: Long,
    val followingId: Long,
    val isPending: Boolean = false, // If true, follow request is pending
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "stories")
data class StoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val mediaUrl: String,
    val caption: String = "",
    val expiresAt: Long = System.currentTimeMillis() + 86400000, // 24 Hours default
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val senderId: Long,
    val receiverId: Long,
    val message: String,
    val imageUrl: String? = null,
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long, // Notification receiver
    val senderId: Long, // Notification triggerer
    val type: String, // "LIKE", "COMMENT", "FOLLOW", "FOLLOW_REQUEST", "MESSAGE"
    val referenceId: Long, // post_id, comment_id, message_id
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

class Converters {
    @TypeConverter
    fun fromString(value: String?): List<String> {
        return value?.split(",")?.filter { it.trim().isNotEmpty() } ?: emptyList()
    }

    @TypeConverter
    fun toString(list: List<String>?): String {
        return list?.joinToString(",") ?: ""
    }
}
