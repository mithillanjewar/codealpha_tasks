package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: Long): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserByIdFlow(id: Long): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("SELECT * FROM users")
    fun getAllUsersFlow(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE username LIKE '%' || :query || '%' OR fullName LIKE '%' || :query || '%'")
    suspend fun searchUsers(query: String): List<UserEntity>
}

@Dao
interface PostDao {
    @Query("SELECT * FROM posts ORDER BY createdAt DESC")
    fun getAllPostsFlow(): Flow<List<PostEntity>>

    @Query("SELECT * FROM posts WHERE userId = :userId ORDER BY createdAt DESC")
    fun getPostsByUserIdFlow(userId: Long): Flow<List<PostEntity>>

    @Query("SELECT * FROM posts WHERE id = :id LIMIT 1")
    suspend fun getPostById(id: Long): PostEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: PostEntity): Long

    @Update
    suspend fun updatePost(post: PostEntity)

    @Delete
    suspend fun deletePost(post: PostEntity)

    @Query("SELECT * FROM posts WHERE caption LIKE '%' || :query || '%' OR hashtags LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    suspend fun searchPosts(query: String): List<PostEntity>
}

@Dao
interface CommentDao {
    @Query("SELECT * FROM comments WHERE postId = :postId ORDER BY createdAt ASC")
    fun getCommentsByPostIdFlow(postId: Long): Flow<List<CommentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentEntity): Long

    @Query("DELETE FROM comments WHERE id = :id")
    suspend fun deleteComment(id: Long)

    @Query("SELECT COUNT(*) FROM comments WHERE postId = :postId")
    fun getCommentsCountFlow(postId: Long): Flow<Int>
}

@Dao
interface LikeDao {
    @Query("SELECT * FROM likes WHERE userId = :userId AND postId = :postId LIMIT 1")
    suspend fun getPostLike(userId: Long, postId: Long): LikeEntity?

    @Query("SELECT * FROM likes WHERE userId = :userId AND commentId = :commentId LIMIT 1")
    suspend fun getCommentLike(userId: Long, commentId: Long): LikeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLike(like: LikeEntity): Long

    @Delete
    suspend fun deleteLike(like: LikeEntity)

    @Query("SELECT COUNT(*) FROM likes WHERE postId = :postId AND commentId IS NULL")
    fun getPostLikesCountFlow(postId: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM likes WHERE commentId = :commentId")
    fun getCommentLikesCountFlow(commentId: Long): Flow<Int>

    @Query("SELECT * FROM likes WHERE postId = :postId AND commentId IS NULL")
    fun getPostLikesFlow(postId: Long): Flow<List<LikeEntity>>
}

@Dao
interface FollowerDao {
    @Query("SELECT * FROM followers WHERE followingId = :userId AND isPending = 0")
    fun getFollowersFlow(userId: Long): Flow<List<FollowerEntity>>

    @Query("SELECT * FROM followers WHERE followerId = :userId AND isPending = 0")
    fun getFollowingFlow(userId: Long): Flow<List<FollowerEntity>>

    @Query("SELECT * FROM followers WHERE followingId = :userId AND isPending = 1")
    fun getPendingRequestsFlow(userId: Long): Flow<List<FollowerEntity>>

    @Query("SELECT * FROM followers WHERE followerId = :followerId AND followingId = :followingId LIMIT 1")
    suspend fun getFollowRecord(followerId: Long, followingId: Long): FollowerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFollow(follower: FollowerEntity): Long

    @Update
    suspend fun updateFollow(follower: FollowerEntity)

    @Delete
    suspend fun deleteFollow(follower: FollowerEntity)
}

@Dao
interface StoryDao {
    @Query("SELECT * FROM stories WHERE expiresAt > :now ORDER BY createdAt DESC")
    fun getActiveStoriesFlow(now: Long = System.currentTimeMillis()): Flow<List<StoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: StoryEntity): Long

    @Query("DELETE FROM stories WHERE id = :id")
    suspend fun deleteStory(id: Long)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE (senderId = :userId AND receiverId = :otherId) OR (senderId = :otherId AND receiverId = :userId) ORDER BY createdAt ASC")
    fun getMessagesFlow(userId: Long, otherId: Long): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE senderId = :userId OR receiverId = :userId ORDER BY createdAt DESC")
    fun getAllUserMessagesFlow(userId: Long): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity): Long

    @Query("UPDATE messages SET isRead = 1 WHERE senderId = :otherId AND receiverId = :userId")
    suspend fun markMessagesAsRead(userId: Long, otherId: Long)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY createdAt DESC")
    fun getNotificationsFlow(userId: Long): Flow<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE userId = :userId AND isRead = 0")
    fun getUnreadCountFlow(userId: Long): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId")
    suspend fun markAllAsRead(userId: Long)

    @Query("DELETE FROM notifications WHERE id = :id")
    suspend fun deleteNotification(id: Long)
}
